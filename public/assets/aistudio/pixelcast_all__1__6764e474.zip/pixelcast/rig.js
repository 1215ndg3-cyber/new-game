/* PixelRig：像素人物通用骨架与渲染（无 DOM，浏览器和 Node 都能用）
 * 角度约定：以“垂直向下”为 0，朝向前方为正，单位度。人物默认朝右，镜像得到朝左。
 * 一个人物 = 骨架(SKELETON) + 角色规格(spec: build/look/gait/idle) + 姿势(pose)。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PixelRig = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const GW = 32, GH = 80, GOFF = 30, FOOT = 45, SHY = 35;
  const rad = d => d * Math.PI / 180;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  const SKELETON = {
    note: '像素人物通用骨架。角度以垂直向下为0，朝前为正，单位度；默认朝右，镜像得到朝左。',
    grid: { width: GW, height: GH, rowOffset: GOFF, footRow: FOOT, standingHipRow: SHY, spriteCell: [32, 48] },
    defaultBuild: { thigh: 6, shin: 5, upper: 3, fore: 3 },
    bones: [
      { name: 'pelvis', parent: null, note: '根骨骼，髋关节在 列15.5、行hy，骨盆2行' },
      { name: 'torso', parent: 'pelvis', length: 4, widthPx: 2, note: '躯干4行，宽2（45°视角肩宽4）；lean 让上身逐行前倾，bob 让上身整体上下 ±1 行' },
      { name: 'neck', parent: 'torso', length: 1 },
      { name: 'head', parent: 'neck', size: [5, 5], note: '头 5列x5行（侧面）/6列x5行（45°）。上两行全是头发，脸从第3行开始；head:[dx,dy] 可整体偏移（低头、探头）' },
      { name: 'upperArmNear', parent: 'torso', length: 3, note: '肩在 列16+lean、行hy-7+bob，角度 na[0]' },
      { name: 'foreArmNear', parent: 'upperArmNear', length: 3, note: '角度 na[1]，末端是手' },
      { name: 'upperArmFar', parent: 'torso', length: 3, note: '肩在 列15+lean，画在身体后面，角度 fa[0]' },
      { name: 'foreArmFar', parent: 'upperArmFar', length: 3, note: '角度 fa[1]' },
      { name: 'thighNear', parent: 'pelvis', length: 6, note: '宽2像素，角度 nl[0]' },
      { name: 'shinNear', parent: 'thighNear', length: 5, note: '角度 nl[1]（绝对角，不是相对角）' },
      { name: 'footNear', parent: 'shinNear', length: 3, note: '脚3像素，朝前' },
      { name: 'thighFar', parent: 'pelvis', length: 6, note: '角度 fl[0]' },
      { name: 'shinFar', parent: 'thighFar', length: 5, note: '角度 fl[1]' },
      { name: 'footFar', parent: 'shinFar', length: 3 },
      { name: 'hairChain', parent: 'head', note: '马尾/长发/外套下摆：两节链，角度 tail[0]、tail[1]，表示向后下方的飘动' }
    ],
    view34: '待机用 45° 视角：po.v34=true；此时 na/fa 为画面左/右臂、nl/fl 为画面左/右腿，角度在画面平面内（向下为0，向画面右为正）',
    pose: {
      nl: '近侧腿 [大腿角, 小腿绝对角]', fl: '远侧腿', na: '近侧手臂 [上臂角, 前臂角]', fa: '远侧手臂',
      tail: '头发/外套飘动 [第一节角, 第二节角]', lean: '躯干前倾像素 0..2（-1 为后仰）', bob: '上身下沉像素（呼吸、叹气、缩肩）',
      head: '[dx,dy] 头部偏移', blink: '是否闭眼'
    }
  };

  const mkG = () => Array.from({ length: GH }, () => Array(GW).fill(null));
  function put(g, x, y, c) { x = Math.round(x); y = Math.round(y); if (c && x >= 0 && y >= 0 && x < GW && y < GH) g[y][x] = c; }
  function line(g, x0, y0, x1, y1, c, w) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), stx = x0 < x1 ? 1 : -1, sty = y0 < y1 ? 1 : -1;
    let e = dx + dy;
    while (true) {
      for (let i = 0; i < w; i++) put(g, x0 + i, y0, c);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * e;
      if (e2 >= dy) { e += dy; x0 += stx; }
      if (e2 <= dx) { e += dx; y0 += sty; }
    }
  }
  function legPts(b, th, sh) {
    const kx = b.thigh * Math.sin(rad(th)), ky = b.thigh * Math.cos(rad(th));
    return { kx, ky, ax: kx + b.shin * Math.sin(rad(sh)), ay: ky + b.shin * Math.cos(rad(sh)) };
  }
  function armPts(b, u, f) {
    const ex = b.upper * Math.sin(rad(u)), ey = b.upper * Math.cos(rad(u));
    return { ex, ey, wx: ex + b.fore * Math.sin(rad(f)), wy: ey + b.fore * Math.cos(rad(f)) };
  }
  function gHy(b, po) {
    const a = legPts(b, po.nl[0], po.nl[1]), c = legPts(b, po.fl[0], po.fl[1]);
    return FOOT - Math.max(Math.round(a.ay), Math.round(c.ay));
  }
  function drawLeg2(g, L, hx, hy, cols) {
    line(g, hx, hy, hx + L.kx, hy + L.ky, cols[0], 2);
    line(g, hx + L.kx, hy + L.ky, hx + L.ax, hy + L.ay, cols[1], 2);
    const ax = Math.round(hx + L.ax), ay = Math.round(hy + L.ay);
    for (let i = 0; i < 3; i++) put(g, ax + i, ay, cols[2]);
  }
  function drawArm2(g, A, sx, sy, cols, thick) {
    if (thick) {                                      // 袖子：靠肩膀的前 2/3 上臂加粗到 2 像素
      const px = sx + A.ex * 0.67, py = sy + A.ey * 0.67, off = thick < 0 ? -1 : 0;
      line(g, sx + off, sy, px + off, py, cols[0], 2);
    }
    line(g, sx, sy, sx + A.ex, sy + A.ey, cols[0], 1);
    line(g, sx + A.ex, sy + A.ey, sx + A.wx, sy + A.wy, cols[1], 1);
    put(g, sx + A.wx, sy + A.wy, cols[2]);
  }

  /* 头部像素图：[dx,dy,色键]  h发 H发高光 s皮肤 e眼 a耳/皮肤暗部 x帽 X帽高光 b帽檐
   * 侧面：5列x5行（dy=-1 是发髻/帽顶）。前两行全是头发，脸从第3行(dy=2)开始，眼睛旁边紧挨着一列皮肤 → 脸 2 列宽 */
  const FACE = [[0,2,'h'],[1,2,'h'],[2,2,'h'],[3,2,'h'],[4,2,'s'],
    [0,3,'h'],[1,3,'a'],[2,3,'h'],[3,3,'s'],[4,3,'s'],
    [0,4,'h'],[1,4,'h'],[2,4,'h'],[3,4,'s'],[4,4,'s']];
  const TOP = [[0,0,'h'],[1,0,'h'],[2,0,'H'],[3,0,'h'],[4,0,'h'],[0,1,'h'],[1,1,'h'],[2,1,'h'],[3,1,'H'],[4,1,'h']];
  const HEADS = {
    ponytail: [[1,-1,'h'],[2,-1,'h']].concat(TOP, FACE),
    short: [[1,-1,'h'],[2,-1,'H'],[3,-1,'h']].concat(TOP, FACE),
    long: TOP.concat(FACE),
    cap: [[1,-1,'x'],[2,-1,'X'],[3,-1,'x'],[0,0,'x'],[1,0,'x'],[2,0,'X'],[3,0,'x'],[4,0,'x'],[0,1,'x'],[1,1,'x'],[2,1,'x'],[3,1,'x'],[4,1,'x'],[5,1,'b'],
      [0,2,'h'],[1,2,'h'],[2,2,'h'],[3,2,'h'],[4,2,'a'],[0,3,'h'],[1,3,'a'],[2,3,'h'],[3,3,'s'],[4,3,'s'],[0,4,'h'],[1,4,'h'],[2,4,'h'],[3,4,'s'],[4,4,'s']],
    bob: TOP.concat(FACE.slice(0, 14), [[0,5,'h'],[1,5,'h'],[2,5,'h']])
  };
  /* 45° 视角头：6列x5行，脸 2 列宽居中偏右，左侧露出耳/脸颊，头发在两侧包住 */
  const FACE34 = [[0,2,'h'],[1,2,'h'],[2,2,'h'],[3,2,'s'],[4,2,'s'],
    [0,3,'h'],[1,3,'a'],[2,3,'h'],[3,3,'s'],[4,3,'s'],
    [0,4,'h'],[1,4,'a'],[2,4,'h'],[3,4,'s'],[4,4,'s']];
  const TOP34 = [[0,0,'h'],[1,0,'h'],[2,0,'H'],[3,0,'h'],[4,0,'h'],[5,0,'h'],[0,1,'h'],[1,1,'h'],[2,1,'h'],[3,1,'H'],[4,1,'h'],[5,1,'h']];
  const HEADS34 = {
    ponytail: [[1,-1,'h'],[2,-1,'h']].concat(TOP34, FACE34),
    short: [[1,-1,'h'],[2,-1,'H'],[3,-1,'h']].concat(TOP34, FACE34),
    long: TOP34.concat(FACE34, []),
    cap: [[1,-1,'x'],[2,-1,'X'],[3,-1,'x'],[4,-1,'x'],[0,0,'x'],[1,0,'x'],[2,0,'X'],[3,0,'x'],[4,0,'x'],[5,0,'x'],[0,1,'x'],[1,1,'x'],[2,1,'x'],[3,1,'x'],[4,1,'x'],[5,1,'x'],[6,1,'b'],[7,1,'b'],
      [0,2,'h'],[1,2,'h'],[2,2,'h'],[3,2,'a'],[4,2,'a'],[0,3,'h'],[1,3,'a'],[2,3,'h'],[3,3,'s'],[4,3,'s'],[0,4,'h'],[1,4,'a'],[2,4,'h'],[3,4,'s'],[4,4,'s']],
    bob: TOP34.concat(FACE34, [[0,5,'h'],[1,5,'h']])
  };
  function headKey(look, po) {
    const c = look.cols;
    return { h: c.hair, H: c.hairHi || c.hair, s: c.skin, e: po.blink ? c.skin : c.eye, a: c.skinSh || c.skin, x: c.hat, X: c.hatHi || c.hat, b: c.hatBrim || c.hat };
  }
  function drawHead(g, look, po, ox, oy) {
    const map = HEADS[look.hair] || HEADS.ponytail, key = headKey(look, po);
    for (const m of map) put(g, ox + m[0], oy + m[1], key[m[2]]);
  }
  function drawHead34(g, look, po, ox, oy) {
    const map = HEADS34[look.hair] || HEADS34.ponytail, key = headKey(look, po);
    for (const m of map) put(g, ox + m[0], oy + m[1], key[m[2]]);
  }
  function drawFlask(g, hx, hy, dx, dy, c) {
    const cx = Math.round(hx + dx * 1.6), cy = Math.round(hy + dy * 1.6 - 0.5);
    put(g, cx, cy - 2, '#7a5a3a'); put(g, cx, cy - 1, c.glass || '#d6e6ee');
    put(g, cx - 1, cy, c.glass || '#d6e6ee'); put(g, cx, cy, c.liquid || '#b5523a'); put(g, cx + 1, cy, c.liquid || '#b5523a');
    put(g, cx - 1, cy + 1, c.liquid || '#b5523a'); put(g, cx, cy + 1, c.liquid2 || '#8e3a28'); put(g, cx + 1, cy + 1, c.liquid2 || '#8e3a28');
  }

  /* 画一个完整人物到网格 g（hy 为髋所在行，已含 GOFF） */
  function drawCharacter(g, spec, po, hy) {
    const b = spec.build, look = spec.look, c = look.cols, o = look.outfit;
    if (po.v34) return drawChar34(g, spec, po, hy);
    const L = po.lean || 0, ub = po.bob || 0, hd = po.head || [0, 0], hx = 15, sy = hy - 6 + ub;
    const LN = legPts(b, po.nl[0], po.nl[1]), LF = legPts(b, po.fl[0], po.fl[1]);
    const shf = y => Math.round(L * (hy - 3 - y) / 4);
    const ox = 13 + L + hd[0], oy = hy - 12 + ub + hd[1];
    drawArm2(g, armPts(b, po.fa[0], po.fa[1]), 15 + L, sy, c.armF, o === 'labcoat' ? -1 : 0);
    drawLeg2(g, LF, hx, hy, c.legF);
    if (o === 'labcoat') {                           // 白大褂敞开：只有身后的下摆随风飘，前面露出里面的深色衣服
      const fly = Math.round(clamp(((po.tail ? po.tail[0] : 30) - 10) / 25, 0, 2));
      for (let y = hy - 2; y <= hy + 4; y++) {
        const back = y >= hy + 1 ? fly : 0;
        for (let x = 13 - back + L; x <= 14 + L; x++) put(g, x, y, y === hy + 4 || x < 14 + L ? c.coatSh : c.coat);
      }
    }
    if (look.hair === 'long') {
      const t0 = po.tail ? po.tail[0] : 30;
      for (let r = 0; r < 8; r++) {
        const dx = Math.round(-Math.sin(rad(clamp(t0, -20, 70))) * r * 0.45), x0 = ox - 1 + dx;
        put(g, x0, oy + 2 + r, c.hair); put(g, x0 + 1, oy + 2 + r, r % 3 === 1 ? c.hairHi : c.hair);
      }
    }
    for (let y = hy - 6 + ub; y <= hy - 3; y++) {
      const s = shf(y);
      let bk = c.topSh || c.top, fr = c.top;
      if (o === 'labcoat') { bk = c.coat; fr = c.top; }
      else if (o === 'overalls') { bk = c.top; fr = c.bib; }
      if (y === hy - 6 + ub) {
        if (o === 'labcoat') { bk = c.coat; fr = c.coat; } else if (o === 'vest') fr = c.collar; else if (o === 'hoodie') { fr = c.hood; bk = c.hood; } else if (o === 'overalls') bk = c.bib;
      }
      if (y === hy - 3 && c.belt) { bk = c.belt; fr = c.belt; }
      put(g, 15 + s, y, bk); put(g, 16 + s, y, fr);
    }
    for (let y = hy - 2; y <= hy - 1; y++) { put(g, 15, y, c.pelvis); put(g, 16, y, c.pelvis); }
    if (hd[1] <= 0) put(g, 16 + L, hy - 7 + ub, c.skinSh || c.skin);
    if (o === 'hoodie') { put(g, ox, oy + 5, c.hood); put(g, ox + 1, oy + 5, c.hood); put(g, ox, oy + 6, c.hood); }
    if (look.hair === 'ponytail') {
      const a1 = rad(po.tail[0]), a2 = rad(po.tail[1]);
      const p0 = [ox + 1, oy], p1 = [p0[0] - 2 * Math.cos(a1), p0[1] + 2 * Math.sin(a1)], p2 = [p1[0] - 2 * Math.cos(a2), p1[1] + 2 * Math.sin(a2)];
      line(g, p0[0], p0[1], p1[0], p1[1], c.hair, 1); line(g, p1[0], p1[1], p2[0], p2[1], c.hair, 1); put(g, p2[0], p2[1], c.hairEnd || c.hair);
    }
    drawHead(g, look, po, ox, oy);
    drawLeg2(g, LN, hx, hy, c.legN);
    const AN = armPts(b, po.na[0], po.na[1]);
    if (look.prop === 'flask') {
      const hxp = 16 + L + AN.wx, hyp = sy + AN.wy, f = rad(po.na[1]);
      drawFlask(g, hxp, hyp, Math.sin(f), Math.cos(f), c);
    }
    drawArm2(g, AN, 16 + L, sy, c.armN, o === 'labcoat' ? 1 : 0);
  }

  /* ---------- 45° 视角（待机用）----------
   * 身体微转向观众：肩 4 宽、躯干 2 宽、双臂分在两侧、两条腿并排；头 6 列，脸 2 列宽、露出一侧耳朵。
   * 姿势字段：na/fa = 画面左/右臂 [上臂角,前臂角]；nl/fl = 画面左/右腿；角度在画面平面内，向下为0，向画面右为正。 */
  function drawLeg34(g, L, hx, hy, cols, side) {
    line(g, hx, hy, hx + L.kx, hy + L.ky, cols[0], 2);
    line(g, hx + L.kx, hy + L.ky, hx + L.ax, hy + L.ay, cols[1], 2);
    const ax = Math.round(hx + L.ax), ay = Math.round(hy + L.ay);
    for (let i = 0; i < 3; i++) put(g, (side < 0 ? ax - 1 : ax) + i, ay, cols[2]);
  }
  function drawChar34(g, spec, po, hy) {
    const b = spec.build, look = spec.look, c = look.cols, o = look.outfit;
    const ub = po.bob || 0, hd = po.head || [0, 0], ox = 12 + hd[0], oy = hy - 12 + ub + hd[1], sy = hy - 6 + ub;
    const LA = armPts(b, po.na[0], po.na[1]), RA = armPts(b, po.fa[0], po.fa[1]);
    const LL = legPts(b, po.nl[0], po.nl[1]), RL = legPts(b, po.fl[0], po.fl[1]);
    const t0 = po.tail ? po.tail[0] : 30;
    // 后层：右臂(远)、实验服下摆、长发
    const sl = o === 'labcoat';
    drawArm2(g, RA, 17, sy, c.armF, sl ? 1 : 0);
    if (look.hair === 'long') {
      for (let r = 0; r < 8; r++) {
        const dx = Math.round(-Math.sin(rad(clamp(t0 - 20, -10, 40))) * r * 0.35), x0 = ox + dx;
        put(g, x0, oy + 2 + r, c.hair); put(g, x0 + 1, oy + 2 + r, r % 3 === 1 ? c.hairHi : c.hair);
      }
    }
    drawLeg34(g, RL, 16, hy, c.legF, 1);
    drawLeg34(g, LL, 14, hy, c.legN, -1);
    // 躯干
    for (let y = hy - 6 + ub; y <= hy - 3; y++) {
      let bk = c.topSh || c.top, fr = c.top;
      if (o === 'overalls') { bk = c.top; fr = c.bib; }
      const top = y === hy - 6 + ub;
      if (o === 'labcoat') {
        bk = c.top; fr = c.top; if (y === hy - 3 && c.belt) { bk = c.belt; fr = c.belt; }
        put(g, 14, y, top ? c.coat : c.coatSh); put(g, 17, y, c.coat); put(g, 15, y, top ? c.coat : bk); put(g, 16, y, top ? c.top : fr);   // 翻领：领口一侧是白的
        continue;
      }
      if (top) { if (o === 'vest') fr = c.collar; else if (o === 'hoodie') { fr = c.hood; bk = c.hood; } else if (o === 'overalls') bk = c.bib; }
      if (y === hy - 3 && c.belt) { bk = c.belt; fr = c.belt; }
      if (top) { put(g, 14, y, bk); put(g, 15, y, fr); put(g, 16, y, fr); put(g, 17, y, bk); }
      else { put(g, 15, y, bk); put(g, 16, y, fr); }
    }
    if (o === 'labcoat') {                           // 白大褂半穿、没扣扣子：中间露出里面的深色衣服和裤子，白色只在两侧垂下
      const sway = Math.round(clamp((t0 - 20) / 30, 0, 1));
      for (let y = hy - 2; y <= hy - 1; y++) { put(g, 15, y, c.pelvis); put(g, 16, y, c.pelvis); }
      for (let y = hy - 2; y <= hy + 5; y++) {
        const k = y - (hy - 2), wl = k >= 4 ? 2 : 1;                  // 越往下越外翻
        put(g, 14, y, c.coatSh); if (wl > 1) put(g, 13, y, c.coatSh);
        put(g, 17, y, c.coat); if (wl > 1) put(g, 18, y, c.coat);
        if (y === hy + 5) { put(g, 12 - sway, y, c.coatSh); put(g, 19 + sway, y, c.coat); }
      }
    } else for (let y = hy - 2; y <= hy - 1; y++) { put(g, 15, y, c.pelvis); put(g, 16, y, c.pelvis); }
    if (hd[1] <= 0) { put(g, 15, hy - 7 + ub, c.skinSh || c.skin); if (o === 'hoodie') { put(g, 14, hy - 7 + ub, c.hood); put(g, 16, hy - 7 + ub, c.hood); } }
    if (look.hair === 'ponytail') {      // 发尾挂在脑后左侧，几乎垂直下落
      const a1 = rad(po.tail[0]), a2 = rad(po.tail[1]);
      const p0 = [ox, oy + 1], p1 = [p0[0] - 2 * Math.cos(a1), p0[1] + 2 * Math.sin(a1)], p2 = [p1[0] - 2 * Math.cos(a2), p1[1] + 2 * Math.sin(a2)];
      line(g, p0[0], p0[1], p1[0], p1[1], c.hair, 1); line(g, p1[0], p1[1], p2[0], p2[1], c.hair, 1); put(g, p2[0], p2[1], c.hairEnd || c.hair);
    }
    drawHead34(g, look, po, ox, oy);
    if (o === 'hoodie') { put(g, ox + 1, oy + 5, c.hood); put(g, ox + 4, oy + 5, c.hood); }
    // 前层：左臂(近)，可能拿烧瓶
    if (look.prop === 'flask') { const f = rad(po.na[1]); drawFlask(g, 14 + LA.wx, sy + LA.wy, Math.sin(f), Math.cos(f), c); }
    drawArm2(g, LA, 14, sy, c.armN, sl ? -1 : 0);
  }
  function charGrid(spec, po, hy, phi) {
    const g = mkG(); drawCharacter(g, spec, po, hy + GOFF);
    if (!phi) return g;
    const o = mkG(), cc = Math.cos(rad(phi)), ss = Math.sin(rad(phi)), cx = 16, cy = hy + GOFF - 3;
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const dx = x + 0.5 - cx, dy = y + 0.5 - cy, sx = Math.floor(cx + dx * cc + dy * ss), sy = Math.floor(cy - dx * ss + dy * cc);
      if (sx >= 0 && sy >= 0 && sx < GW && sy < GH && g[sy][sx]) o[y][x] = g[sy][sx];
    }
    return o;
  }

  /* ---------- 姿势库 ---------- */
  const norm = po => Object.assign({ head: [0, 0], lean: 0, bob: 0, tail: [28, 58] }, po);
  const mixArr = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
  function blend(a, b, t) {
    a = norm(a); b = norm(b);
    const o = {};
    for (const k of ['nl', 'fl', 'na', 'fa', 'tail', 'head']) o[k] = mixArr(a[k], b[k], t);
    o.lean = Math.round(a.lean + (b.lean - a.lean) * t); o.bob = Math.round(a.bob + (b.bob - a.bob) * t);
    o.blink = b.blink; return o;
  }
  function walkBase(i, sw) {
    const p = i / 8 * Math.PI * 2, q = p + Math.PI, nth = 30 * Math.sin(p), fth = 30 * Math.sin(q);
    const nb = 8 + 50 * Math.max(0, Math.cos(p)), fb = 8 + 50 * Math.max(0, Math.cos(q));
    const nu = -30 * Math.sin(p) * sw, fu = -30 * Math.sin(q) * sw;
    return norm({ nl: [nth, nth - nb], fl: [fth, fth - fb], na: [nu, nu + (22 + 14 * Math.max(0, -Math.sin(p))) * sw], fa: [fu, fu + (22 + 14 * Math.max(0, -Math.sin(q))) * sw],
      tail: [28 + 14 * Math.sin(p - 0.5), 58 + 14 * Math.sin(p - 0.5) + 14 * Math.sin(p - 1.5)] });
  }
  const RL = [[30, 22], [32, -55], [-5, -12], [-30, -40], [-25, -95], [5, -100], [40, -60], [55, 10]];
  function runBase(i) {
    const sn = Math.sin(2 * Math.PI * (i - 1.5) / 8), sf = Math.sin(2 * Math.PI * (i + 4 - 1.5 - 0.4) / 8);
    const un = 5 + 50 * sn, uf = 5 + 46 * sf, p = i / 8 * Math.PI * 2, fl = (i === 3 || i === 7) ? 6 : 0, a1 = 8 + 10 * Math.sin(p - 0.5) - fl;
    return norm({ nl: RL[i], fl: RL[(i + 4) % 8], na: [un, un + 70 + 25 * sn], fa: [uf, uf + 68 + 22 * sf], tail: [a1, a1 + 14 + 10 * Math.sin(p - 1.5)], lean: 1 });
  }
  const ARM = { cross: [[30, -85], [30, -85]], chin: [[58, 172], [25, -80]], hips: [[30, -70], [30, -70]], hug: [[10, -100], [10, -100]], flask: [[82, 128], null] };
  const P = {
    skid: { nl: [38, 28], fl: [-18, -40], na: [70, 110], fa: [-60, -100], tail: [50, 75], lean: -1 },
    crouch: { nl: [42, -40], fl: [36, -44], na: [-50, -20], fa: [-25, -5], tail: [35, 62] },
    spring: { nl: [22, -28], fl: [18, -30], na: [28, 55], fa: [8, 35], tail: [40, 65] },
    land: { nl: [55, -50], fl: [48, -55], na: [30, 75], fa: [10, 40], tail: [50, 75] },
    tuck: { nl: [95, -30], fl: [100, -35], na: [45, 85], fa: [20, 60], tail: [30, 55] }
  };
  const AK = [
    [2.5, { nl: [-8, -12], fl: [-4, -8], na: [135, 170], fa: [60, 100], tail: [55, 80] }],
    [1.6, { nl: [-15, -35], fl: [50, 5], na: [110, 160], fa: [-35, -95], tail: [45, 70] }],
    [0.8, { nl: [5, -45], fl: [60, 15], na: [95, 140], fa: [-55, -100], tail: [30, 55] }],
    [0.0, { nl: [30, -30], fl: [65, 5], na: [75, 120], fa: [-50, -85], tail: [10, 32] }],
    [-0.8, { nl: [20, -15], fl: [45, 5], na: [100, 150], fa: [-70, -140], tail: [-10, 10] }],
    [-1.6, { nl: [5, -8], fl: [15, 0], na: [125, 160], fa: [-55, -120], tail: [-30, -8] }],
    [-2.6, { nl: [12, 0], fl: [-10, -10], na: [60, 100], fa: [-35, -70], tail: [-20, 0] }]
  ];
  function airPose(v) {
    if (v >= AK[0][0]) return norm(AK[0][1]);
    for (let i = 0; i < AK.length - 1; i++) if (v <= AK[i][0] && v > AK[i + 1][0]) return blend(AK[i][1], AK[i + 1][1], (AK[i][0] - v) / (AK[i][0] - AK[i + 1][0]));
    return norm(AK[AK.length - 1][1]);
  }

  /* ---------- 性格专属待机骨架动作 ---------- */
  const ph = (t, c) => ((t % c) + c) % c;
  const IDLES = {
    // 冷静：抱臂，慢呼吸，偶尔换重心
    cross(t, talk) {
      const u = ph(t, 3.2) / 3.2, bob = u < 0.38 ? 0 : u < 0.72 ? -1 : 0, sh = ph(t, 7.5);
      const shift = sh > 5.8 && sh < 6.7;
      return norm({ nl: shift ? [10, 5] : [3, 0], fl: shift ? [-8, -7] : [-3, -2], na: ARM.cross[0], fa: ARM.cross[1], tail: [26 + 3 * Math.sin(t * 1.6), 52 + 4 * Math.sin(t * 1.9)], bob, head: [0, talk && Math.sin(t * 7) > 0.6 ? 1 : 0] });
    },
    // 沉思：手托下巴，低头，指尖轻敲
    think(t, talk) {
      const u = ph(t, 3.8) / 3.8, bob = u < 0.4 ? 0 : u < 0.75 ? -1 : 0, look = ph(t, 9) < 4 ? 1 : 0, tap = ph(t, 2.6) > 2.25 ? 1 : 0;
      return norm({ nl: [6, 0], fl: [-5, -4], na: [58 + (tap ? 8 : 0), 172 - (tap ? 10 : 0)], fa: ARM.chin[1], tail: [30, 55], lean: look, bob, head: [0, talk ? (Math.sin(t * 5) > 0 ? 1 : 0) : look] });
    },
    // 健谈：举着瓶子比划，脚尖弹跳，点头
    talk(t) {
      const s = Math.sin(t * 3.2), bob = Math.sin(t * 6.5) > 0.4 ? -1 : 0;
      return norm({ nl: [3 + (bob ? 0 : 6), bob ? 0 : -8], fl: [-3, -2 - (bob ? 0 : 6)], na: [98 + 18 * s, 142 + 22 * Math.sin(t * 3.2 + 0.8)],
        fa: [45 + 30 * Math.sin(t * 2.4 + 1), 85 + 25 * Math.sin(t * 2.4 + 1.6)], tail: [20 + 10 * Math.sin(t * 3), 45 + 12 * Math.sin(t * 3 + 1)], bob, head: [0, Math.sin(t * 3.2) > 0.7 ? 1 : 0] });
    },
    // 暴躁：叉腰，分腿站，跺脚，叹气
    hips(t, talk) {
      const st = ph(t, 3.4), stomp = st > 2.9 && st < 3.15, sg = ph(t, 6.5), sigh = sg > 5.2 && sg < 6.0;
      const na = talk ? [85 + 15 * Math.sin(t * 4), 120] : ARM.hips[0];
      return norm({ nl: stomp ? [34, -34] : [12, 6], fl: [-12, -10], na, fa: ARM.hips[1], tail: [25, 50], bob: sigh ? 1 : 0, head: [0, sigh ? 1 : 0] });
    },
    // 胆小：抱住自己，缩肩，脚尖点地，偶尔偷看
    hug(t, talk) {
      const gl = ph(t, 8), glance = gl > 6.6 && gl < 7.3, tp = Math.sin(t * 5) > 0.6 && ph(t, 6) < 2;
      return norm({ nl: [2, 0], fl: tp ? [8, -2] : [0, 0], na: ARM.hug[0], fa: ARM.hug[1], tail: [32, 60], lean: glance ? 0 : 1, bob: glance ? 0 : (talk && Math.sin(t * 9) > 0 ? 0 : 1), head: [0, glance ? 0 : 1] });
    }
  };

  /* ---------- 45° 待机（性格专属骨架动作，主用）---------- */
  const n34 = o => Object.assign({ v34: true, head: [0, 0], bob: 0, lean: 0, tail: [72, 86] }, o);
  const sn = Math.sin;
  const IDLES34 = {
    // 冷静：双臂在胸前交叉，慢呼吸，偶尔换重心
    cross(t, talk) {
      const u = ph(t, 3.2) / 3.2, bob = u < 0.38 ? 0 : u < 0.72 ? -1 : 0, sh = ph(t, 7.5), shift = sh > 5.8 && sh < 6.7;
      return n34({ nl: shift ? [-12, -9] : [-4, -2], fl: shift ? [4, 2] : [3, 2], na: [-6, 98], fa: [6, -98],
        tail: [72 + 4 * sn(t * 1.6), 86 + 5 * sn(t * 1.9)], bob, head: [0, talk && sn(t * 7) > 0.6 ? 1 : 0] });
    },
    // 沉思：一只手托下巴、另一只手托住手肘，低头，指尖轻敲
    think(t, talk) {
      const u = ph(t, 3.8) / 3.8, bob = u < 0.4 ? 0 : u < 0.75 ? -1 : 0, look = ph(t, 9) < 4 ? 1 : 0, tap = ph(t, 2.6) > 2.25 ? 1 : 0;
      return n34({ nl: [-3, -2], fl: [4, 3], na: [-5, 92], fa: [50, tap ? 222 : 230], tail: [72, 86], bob, head: [0, talk ? (sn(t * 5) > 0 ? 1 : 0) : look] });
    },
    // 健谈：举着烧瓶比划，另一只手跟着摆，脚尖弹跳，点头
    talk(t) {
      const s = sn(t * 3.2), bob = sn(t * 6.5) > 0.4 ? -1 : 0;
      return n34({ nl: [-4 + (bob ? 0 : -6), -2 + (bob ? 0 : 6)], fl: [4, 3 - (bob ? 0 : 4)], na: [-70 + 15 * s, -165 + 20 * sn(t * 3.2 + 0.8)],
        fa: [55 + 22 * sn(t * 2.4 + 1), 100 + 25 * sn(t * 2.4 + 1.6)], tail: [20 + 8 * sn(t * 3), 40 + 10 * sn(t * 3 + 1)], bob, head: [0, sn(t * 3.2) > 0.7 ? 1 : 0] });
    },
    // 暴躁：双手叉腰，分腿站，跺脚，叹气
    hips(t, talk) {
      const st = ph(t, 3.4), stomp = st > 2.9 && st < 3.15, sg = ph(t, 6.5), sigh = sg > 5.2 && sg < 6.0;
      const na = talk ? [-78 + 12 * sn(t * 4), -105] : [-48, 52];
      return n34({ nl: [-14, -10], fl: stomp ? [26, -26] : [14, 10], na, fa: [48, -52], tail: [30, 50], bob: sigh ? 1 : 0, head: [0, sigh ? 1 : 0] });
    },
    // 胆小：双臂抱住自己，缩肩，膝盖内扣，脚尖点地，偶尔偷看
    hug(t, talk) {
      const gl = ph(t, 8), glance = gl > 6.6 && gl < 7.3, tp = sn(t * 5) > 0.6 && ph(t, 6) < 2;
      return n34({ nl: [5, -2], fl: tp ? [-8, 2] : [-3, 3], na: [-14, 112], fa: [14, -112], tail: [72, 86], bob: glance ? 0 : (talk && sn(t * 9) > 0 ? 0 : 1), head: [glance ? 1 : 0, glance ? 0 : 1] });
    }
  };

  function poser(spec) {
    const b = spec.build, g = spec.gait || {};
    const sw = g.swing == null ? 1 : g.swing;
    return {
      hyGround: po => gHy(b, norm(po)),
      idle: (t, talk) => (spec.idleView === 'side' ? IDLES : IDLES34)[spec.idle](t, talk),
      stand: () => norm({ nl: [3, 0], fl: [-3, -2], na: [6, 14], fa: [-6, -4], tail: [26, 52] }),
      loco(mode, i) {
        if (mode === 'run') { const po = runBase(i); po.lean += g.lean ? 1 : 0; return po; }
        const po = walkBase(i, sw), m = g.walkArms;
        if (m === 'pocket') { po.na = [po.na[0] * 0.5, po.na[0] * 0.5 + 10]; po.fa = [po.fa[0] * 0.5, po.fa[0] * 0.5 + 10]; }
        else if (ARM[m]) { po.na = ARM[m][0]; if (ARM[m][1]) po.fa = ARM[m][1]; }
        po.lean += g.lean || 0;
        if (g.stomp && (i === 0 || i === 4)) po.bob = 1;
        return po;
      },
      runBob: i => i === 3 || i === 7,
      skid: () => norm(P.skid),
      pre: t => norm(t < 0.07 ? P.crouch : P.spring),
      land: t => norm(t < 0.07 ? P.land : P.crouch),
      air: v => airPose(v),
      flip: ft => ({ po: norm(P.tuck), phi: Math.floor(ft / 0.2 * 6) / 6 * 360 })
    };
  }

  return { GW, GH, GOFF, FOOT, SHY, SKELETON, HEADS, IDLES, IDLES34, drawCharacter, charGrid, poser, blend, norm, gHy, rad, clamp };
});
