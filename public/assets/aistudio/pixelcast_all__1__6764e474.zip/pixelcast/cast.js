/* 角色规格：外观、性格参数、待机骨架动作类型、步态、台词。新增角色只需要往 CAST 里加一项。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PixelCast = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const build = { thigh: 6, shin: 5, upper: 3, fore: 3 };
  const CAST = [
    {
      id: 'lin', name: '林', tag: '冷静', desc: '抱着手臂旁观一切的守望者', idle: 'cross', idleName: '抱臂、慢呼吸、偶尔换重心',
      traits: { soc: 0.2, en: 0.3, cau: 0.5, cur: 0.3, pat: 0.9 },
      gait: { walkArms: 'pocket', swing: 0.6, lean: 0 }, build,
      look: { hair: 'ponytail', outfit: 'tee', prop: 'none', cols: {
        skin: '#f3c9a5', skinSh: '#d9a987', eye: '#2a1f1f', hair: '#141414', hairHi: '#2c2c2c', hairEnd: '#0c0c0c',
        top: '#26282c', topSh: '#1b1d20', belt: '#3a3c42', pelvis: '#3b3b3b',
        armN: ['#f3c9a5', '#f3c9a5', '#f3c9a5'], armF: ['#b98b6c', '#b98b6c', '#b98b6c'],
        legN: ['#3b3b3b', '#ffffff', '#2a2a2a'], legF: ['#232220', '#232220', '#a9a9bd'] } },
      lines: {
        greet: ['……', '嗯。', '有事？'], chat: ['风向变了。', '别靠太近。', '无聊。', '走吧。', '随便。'],
        react: ['别碰我。', '嗯？', '……'], refuse: ['没兴趣。'], flee: ['离远点。']
      }
    },
    {
      id: 'bai', name: '白', tag: '沉思', desc: '总在琢磨什么的白发学者', idle: 'think', idleName: '手托下巴、低头、指尖轻敲',
      traits: { soc: 0.4, en: 0.2, cau: 0.6, cur: 0.8, pat: 0.8 },
      gait: { walkArms: 'chin', swing: 0.5, lean: 1 }, build,
      look: { hair: 'short', outfit: 'vest', prop: 'none', cols: {
        skin: '#f1d3bd', skinSh: '#d2b49c', eye: '#3a2a30', hair: '#ecedf1', hairHi: '#ffffff',
        top: '#4b2f46', topSh: '#3a2437', collar: '#f2f2f4', belt: '#2b1e2c', pelvis: '#33263a',
        armN: ['#f2f2f4', '#f2f2f4', '#f1d3bd'], armF: ['#c9c9d0', '#c9c9d0', '#d2b49c'],
        legN: ['#3e2c42', '#3e2c42', '#16121a'], legF: ['#2c2030', '#2c2030', '#0f0c12'] } },
      lines: {
        greet: ['嗯……', '你来得正好。', '我在想一件事。'], chat: ['这说不通。', '再想想。', '也许可以这样。', '有意思……', '我得记下来。'],
        react: ['嗯？', '等一下，我在想。', '有发现吗？'], refuse: ['抱歉，我走神了。'], flee: ['呃……']
      }
    },
    {
      id: 'su', name: '苏', tag: '健谈', desc: '举着烧瓶说个不停的研究员', idle: 'talk', idleName: '举瓶比划、脚尖弹跳、点头',
      traits: { soc: 0.95, en: 0.85, cau: 0.2, cur: 0.7, pat: 0.3 },
      gait: { walkArms: 'flask', swing: 1.2, lean: 0 }, build,
      look: { hair: 'long', outfit: 'labcoat', prop: 'flask', cols: {
        skin: '#e7b896', skinSh: '#c79a7a', eye: '#2a1a18', hair: '#3a2420', hairHi: '#5a3a30',
        top: '#243a42', coat: '#eef2f4', coatSh: '#c2cbd2', belt: '#222a2e', pelvis: '#1d1f24',
        armN: ['#eef2f4', '#eef2f4', '#e7b896'], armF: ['#c2cbd2', '#c2cbd2', '#c79a7a'],
        legN: ['#1d1f24', '#1d1f24', '#111114'], legF: ['#15171b', '#15171b', '#0c0c0e'],
        glass: '#d6e6ee', liquid: '#c4573a', liquid2: '#8e3a28' } },
      lines: {
        greet: ['嗨！', '快来看这个！', '你们听我说！'], chat: ['我的实验成功了！', '来来来，尝尝？', '太神奇了！', '哎呀，洒了！', '再来一次！'],
        react: ['哇！', '你要看我的瓶子吗？', '正好找你！'], refuse: ['那下次再说！'], flee: ['别跑呀！']
      }
    },
    {
      id: 'tie', name: '铁', tag: '暴躁', desc: '戴黄帽子的脾气硬工匠', idle: 'hips', idleName: '叉腰、跺脚、叹气',
      traits: { soc: 0.3, en: 0.5, cau: 0.4, cur: 0.2, pat: 0.5 },
      gait: { walkArms: 'swing', swing: 1.0, lean: 0, stomp: true }, build,
      look: { hair: 'cap', outfit: 'overalls', prop: 'none', cols: {
        skin: '#c98f66', skinSh: '#a8734f', eye: '#241a14', hair: '#3a2a20', hat: '#e09a2e', hatHi: '#f1b650', hatBrim: '#b87a1f',
        top: '#6a6a4a', bib: '#8a8f58', belt: '#4a3a28', pelvis: '#5a5c3c',
        armN: ['#6a6a4a', '#c98f66', '#c98f66'], armF: ['#505038', '#a8734f', '#a8734f'],
        legN: ['#5c5e3e', '#5c5e3e', '#2a2a2a'], legF: ['#46482f', '#46482f', '#1c1c1c'] } },
      lines: {
        greet: ['哼。', '什么事？', '又是你。'], chat: ['活儿还没干完。', '谁碰了我的扳手？', '别挡路。', '又得加班。', '凑合能用。'],
        react: ['别吵！', '干嘛？', '哼！'], refuse: ['没空。'], flee: ['别挡我的路！']
      }
    },
    {
      id: 'mi', name: '米', tag: '胆小', desc: '裹在连帽衫里的怕生少女', idle: 'hug', idleName: '抱住自己、缩肩、偷看',
      traits: { soc: 0.15, en: 0.45, cau: 0.95, cur: 0.4, pat: 0.6 },
      gait: { walkArms: 'hug', swing: 0.4, lean: 1 }, build: { thigh: 5, shin: 5, upper: 3, fore: 3 },
      look: { hair: 'bob', outfit: 'hoodie', prop: 'none', cols: {
        skin: '#f0cfb4', skinSh: '#d3af93', eye: '#2d2220', hair: '#9a4f34', hairHi: '#b9684a',
        top: '#4d7a82', topSh: '#3d6068', hood: '#3d6068', belt: '#3d6068', pelvis: '#2e3a44',
        armN: ['#4d7a82', '#4d7a82', '#f0cfb4'], armF: ['#3d6068', '#3d6068', '#d3af93'],
        legN: ['#2e3a44', '#2e3a44', '#8a8f99'], legF: ['#222c35', '#222c35', '#6e737d'] } },
      lines: {
        greet: ['呃……', '那、那个……', '对、对不起。'], chat: ['我、我先走了……', '别、别看我。', '好可怕。', '嗯、嗯。', '我不太会说话……'],
        react: ['呀！', '别、别过来！', '对不起！'], refuse: ['我、我还有事……'], flee: ['呜……']
      }
    }
  ];
  const AFFINITY = {
    lin: { bai: 0.3, su: 0.1, tie: 0.0, mi: 0.2 }, bai: { lin: 0.3, su: 0.6, tie: 0.1, mi: 0.4 },
    su: { lin: 0.4, bai: 0.8, tie: 0.2, mi: 0.5 }, tie: { lin: 0.2, bai: 0.1, su: -0.2, mi: -0.3 }, mi: { lin: 0.3, bai: 0.5, su: -0.1, tie: -0.6 }
  };
  return { CAST, AFFINITY };
});
