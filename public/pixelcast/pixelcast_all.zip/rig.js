/* PixelRig：像素人物通用骨架与渲染（无 DOM，浏览器和 Node 都能用）
 * 角度约定：以“垂直向下”为 0，朝向前方为正，单位度。人物默认朝右，镜像得到朝左。
 * 一个人物 = 骨架(SKELETON) + 角色规格(spec: build/look/gait/idle) + 姿势(pose)。 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PixelRig = factory();
})(typeof globalThis !== 'undefined' ? globalThis : (typeof self !== 'undefined' ? self : this), function () {
  'use strict';
  const GW = 48, GH = 80, GOFF = 30, GX = 4, FOOT = 45, SHY = 35;
  const rad = d => d * Math.PI / 180;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  const SKELETON = {
    note: '像素人物通用骨架。角度以垂直向下为0，朝前为正，单位度；默认朝右，镜像得到朝左。',
    grid: { width: GW, height: GH, rowOffset: GOFF, colOffset: GX, footRow: FOOT, standingHipRow: SHY, spriteCell: [48, 48] },
    defaultBuild: { thigh: 6, shin: 5, upper: 3, fore: 3 },
    bones: [
      { name: 'pelvis', parent: null, note: '根骨骼，髋关节在 列15.5(+GX=19.5)、行hy，骨盆2行' },
      { name: 'torso', parent: 'pelvis', length: 4, widthPx: 2, note: '躯干4行，宽2（45°视角肩宽4）；lean 让上身逐行前倾，bob 让上身整体上下 ±1 行' },
      { name: 'neck', parent: 'torso', length: 1 },
      { name: 'head', parent: 'neck', size: [5, 5], note: '头 5列x5行（侧面）/6列x5行（45°）。上两行全是头发，脸从第3行开始；head:[dx,dy] 可整体偏移（低头、探头）' },
      { name: 'upperArmNear', parent: 'torso', length: 3, note: '肩在 列16+lean、行hy-7+bob，角度 na[0]' },
      { name: 'foreArmNear', parent: 'upperArmNear', length: 3, note: '角度 na[1]，末端是手' },
      { name: 'upperArmFar', parent: 'torso', length: 3, note: '肩在 列15+lean，画在身体后面，角度 fa[0]' },
      { name: 'foreArmFar', parent: 'upperArmFar', length: 3, note: '角度 fa[1]' },
      { name: 'thighNear', parent: 'pelvis', length: 6, note: '宽2像素，角度 nl[0]' },
      { name: 'shinNear', parent: 'thighNear', length: 5, note: '角度 nl[1]（绝对角，不是相对角）' },
      { name: 'footNear', parent: 'shinNear', length: 3, note: '脚3像素，朝前' },
      { name: 'thighFar', parent: 'pelvis', length: 6, note: '角度 fl[0]' },
      { name: 'shinFar', parent: 'thighFar', length: 5, note: '角度 fl[1]' },
      { name: 'footFar', parent: 'shinFar', length: 3 },
      { name: 'hairChain', parent: 'head', note: '马尾/长发/外套下摆：两节链，角度 tail[0]、tail[1]，表示向后下方的飘动' },
      { name: 'armMount', parent: 'torso', note: '独立手臂挂载枢轴（参考星界边境）：持武器时与躯干/腿部动作解耦，围绕肩关节(16+lean, hy-6+bob)做 360° 鼠标跟随旋转' },
      { name: 'weaponSocket', parent: 'foreArmNear', note: '武器挂点：绑定在主手手腕(wx,wy)，支持手枪瞄准/开火后座/战术换弹与近战挥砍精灵图层' }
    ],
    layers: ['backArm (后臂图层)', 'body (躯干与双腿图层)', 'weapon (武器与弹匣/枪口焰图层)', 'frontArm (前臂与握持手图层)'],
    view34: '待机用 45° 视角：po.v34=true；此时 na/fa 为画面左/右臂、nl/fl 为画面左/右腿，角度在画面平面内（向下为0，向画面右为正）',
    pose: {
      nl: '近侧腿 [大腿角, 小腿绝对角]', fl: '远侧腿', na: '近侧手臂 [上臂角, 前臂角]', fa: '远侧手臂',
      tail: '头发/外套飘动 [第一节角, 第二节角]', lean: '躯干前倾像素 -2..3', bob: '上身下沉像素（呼吸、叹气、缩肩）',
      head: '[dx,dy] 头部偏移', blink: '是否闭眼'
    }
  };

  const mkG = () => Array.from({ length: GH }, () => Array(GW).fill(null));
  function put(g, x, y, c) { x = Math.round(x) + GX; y = Math.round(y); if (c && x >= 0 && y >= 0 && x < GW && y < GH) g[y][x] = c; }
  function recolor(g, x, y, c) { x = Math.round(x) + GX; y = Math.round(y); if (c && x >= 0 && y >= 0 && x < GW && y < GH && g[y][x]) g[y][x] = c; }
  function line(g, x0, y0, x1, y1, c, w) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), stx = x0 < x1 ? 1 : -1, sty = y0 < y1 ? 1 : -1;
    let e = dx + dy;
    while (true) {
      for (let i = 0; i < w; i++) put(g, x0 + i, y0, c);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * e;
      if (e2 >= dy) { e += dy; x0 += stx; }
      if (e2 <= dx) { e += dx; y0 += sty; }
    }
  }
  function legPts(b, th, sh) {
    const kx = b.thigh * Math.sin(rad(th)), ky = b.thigh * Math.cos(rad(th));
    return { kx, ky, ax: kx + b.shin * Math.sin(rad(sh)), ay: ky + b.shin * Math.cos(rad(sh)) };
  }
  function armPts(b, u, f) {
    const ex = b.upper * Math.sin(rad(u)), ey = b.upper * Math.cos(rad(u));
    return { ex, ey, wx: ex + b.fore * Math.sin(rad(f)), wy: ey + b.fore * Math.cos(rad(f)) };
  }
  function gHy(b, po) {
    if (po.hy != null) return po.hy;
    const a = legPts(b, po.nl[0], po.nl[1]), c = legPts(b, po.fl[0], po.fl[1]);
    return FOOT - Math.max(Math.round(a.ay), Math.round(c.ay));
  }
  function drawLeg2(g, L, hx, hy, cols) {
    line(g, hx, hy, hx + L.kx, hy + L.ky, cols[0], 2);
    line(g, hx + L.kx, hy + L.ky, hx + L.ax, hy + L.ay, cols[1], 2);
    const ax = Math.round(hx + L.ax), ay = Math.round(hy + L.ay);
    if (cols[3]) { put(g, ax, ay - 1, cols[3]); put(g, ax + 1, ay - 1, cols[3]); }
    for (let i = 0; i < 3; i++) put(g, ax + i, ay, cols[2]);
  }
  function drawArm2(g, A, sx, sy, cols, thick) {
    if (thick) {                                      // 袖子：靠肩膀的前 2/3 上臂加粗到 2 像素
      const px = sx + A.ex * 0.67, py = sy + A.ey * 0.67, off = thick < 0 ? -1 : 0;
      line(g, sx + off, sy, px + off, py, cols[0], 2);
    }
    line(g, sx, sy, sx + A.ex, sy + A.ey, cols[0], 1);
    line(g, sx + A.ex, sy + A.ey, sx + A.wx, sy + A.wy, cols[1], 1);
    put(g, sx + A.wx, sy + A.wy, cols[2]);
  }

  /* 头部像素图：[dx,dy,色键]  h发 H发高光 s皮肤 e眼 a耳/皮肤暗部 x帽 X帽高光 b帽檐
   * 侧面：5列x5行（dy=-1 是发髻/帽顶）。前两行全是头发，脸从第3行(dy=2)开始，眼睛旁边紧挨着一列皮肤 → 脸 2 列宽 */
  const FACE = [[0,2,'h'],[1,2,'h'],[2,2,'h'],[3,2,'h'],[4,2,'s'],
    [0,3,'h'],[1,3,'a'],[2,3,'h'],[3,3,'s'],[4,3,'s'],
    [0,4,'h'],[1,4,'h'],[2,4,'h'],[3,4,'s'],[4,4,'s']];
  const TOP = [[0,0,'h'],[1,0,'h'],[2,0,'H'],[3,0,'h'],[4,0,'h'],[0,1,'h'],[1,1,'h'],[2,1,'h'],[3,1,'H'],[4,1,'h']];
  const HEADS = {
    ponytail: [[1,-1,'h'],[2,-1,'h']].concat(TOP, FACE),
    short: [[1,-1,'h'],[2,-1,'H'],[3,-1,'h']].concat(TOP, FACE),
    long: TOP.concat(FACE),
    cap: [[1,-1,'x'],[2,-1,'X'],[3,-1,'x'],[0,0,'x'],[1,0,'x'],[2,0,'X'],[3,0,'x'],[4,0,'x'],[0,1,'x'],[1,1,'x'],[2,1,'x'],[3,1,'x'],[4,1,'x'],[5,1,'b'],
      [0,2,'h'],[1,2,'h'],[2,2,'h'],[3,2,'h'],[4,2,'a'],[0,3,'h'],[1,3,'a'],[2,3,'h'],[3,3,'s'],[4,3,'s'],[0,4,'h'],[1,4,'h'],[2,4,'h'],[3,4,'s'],[4,4,'s']],
    bob: TOP.concat(FACE.slice(0, 14), [[0,5,'h'],[1,5,'h'],[2,5,'h']])
  };
  /* 45° 视角头：6列x5行，脸 2 列宽居中偏右，左侧露出耳/脸颊，头发在两侧包住 */
  const FACE34 = [[0,2,'h'],[1,2,'h'],[2,2,'h'],[3,2,'s'],[4,2,'s'],
    [0,3,'h'],[1,3,'a'],[2,3,'h'],[3,3,'s'],[4,3,'s'],
    [0,4,'h'],[1,4,'a'],[2,4,'h'],[3,4,'s'],[4,4,'s']];
  const TOP34 = [[0,0,'h'],[1,0,'h'],[2,0,'H'],[3,0,'h'],[4,0,'h'],[5,0,'h'],[0,1,'h'],[1,1,'h'],[2,1,'h'],[3,1,'H'],[4,1,'h'],[5,1,'h']];
  const HEADS34 = {
    ponytail: [[1,-1,'h'],[2,-1,'h']].concat(TOP34, FACE34),
    short: [[1,-1,'h'],[2,-1,'H'],[3,-1,'h']].concat(TOP34, FACE34),
    long: TOP34.concat(FACE34, []),
    cap: [[1,-1,'x'],[2,-1,'X'],[3,-1,'x'],[4,-1,'x'],[0,0,'x'],[1,0,'x'],[2,0,'X'],[3,0,'x'],[4,0,'x'],[5,0,'x'],[0,1,'x'],[1,1,'x'],[2,1,'x'],[3,1,'x'],[4,1,'x'],[5,1,'x'],[6,1,'b'],[7,1,'b'],
      [0,2,'h'],[1,2,'h'],[2,2,'h'],[3,2,'a'],[4,2,'a'],[0,3,'h'],[1,3,'a'],[2,3,'h'],[3,3,'s'],[4,3,'s'],[0,4,'h'],[1,4,'a'],[2,4,'h'],[3,4,'s'],[4,4,'s']],
    bob: TOP34.concat(FACE34, [[0,5,'h'],[1,5,'h']])
  };
  function headKey(look, po) {
    const c = look.cols;
    return { h: c.hair, H: c.hairHi || c.hair, s: c.skin, e: po.blink ? c.skin : c.eye, a: c.skinSh || c.skin, x: c.hat, X: c.hatHi || c.hat, b: c.hatBrim || c.hat };
  }
  function drawHead(g, look, po, ox, oy) {
    const map = HEADS[look.hair] || HEADS.ponytail, key = headKey(look, po);
    for (const m of map) put(g, ox + m[0], oy + m[1], key[m[2]]);
  }
  function drawHead34(g, look, po, ox, oy) {
    const map = HEADS34[look.hair] || HEADS34.ponytail, key = headKey(look, po);
    for (const m of map) put(g, ox + m[0], oy + m[1], key[m[2]]);
  }
  function drawFlask(g, hx, hy, dx, dy, c) {
    const cx = Math.round(hx + dx * 1.6), cy = Math.round(hy + dy * 1.6 - 0.5);
    put(g, cx, cy - 2, '#7a5a3a'); put(g, cx, cy - 1, c.glass || '#d6e6ee');
    put(g, cx - 1, cy, c.glass || '#d6e6ee'); put(g, cx, cy, c.liquid || '#b5523a'); put(g, cx + 1, cy, c.liquid || '#b5523a');
    put(g, cx - 1, cy + 1, c.liquid || '#b5523a'); put(g, cx, cy + 1, c.liquid2 || '#8e3a28'); put(g, cx + 1, cy + 1, c.liquid2 || '#8e3a28');
  }


  /* ---------- 太空服图层：对任意角色都能穿，所有姿势通用 ---------- */
  const SU = { SW: '#e3e9f1', SS: '#aab8c9', SD: '#6f7f96', AC: '#ef7b3a', BT: '#39455a', GL: '#7fb4e6', HL: '#d6efff', PK: '#9aa6b8', NZ: '#2d3342' };
  const HELM7 = ['..XXX..', '.X...X.', 'X.....X', 'X.....X', 'X.....X', 'X.....X', '.X...X.', '..XXX..'];
  const HELM8 = ['..XXXX..', '.X....X.', 'X......X', 'X......X', 'X......X', 'X......X', '.X....X.', '..XXXX..'];
  const suitCache = new WeakMap();
  function suitSpec(spec) {              // 把角色的衣服/袖子/裤子换成太空服配色，头发收进头盔
    let r = suitCache.get(spec); if (r) return r;
    const lc = spec.look.cols, h = spec.look.hair;
    r = Object.assign({}, spec, { look: Object.assign({}, spec.look, { outfit: 'tee', prop: 'none', hair: (h === 'cap' || h === 'long') ? 'short' : h,
      cols: Object.assign({}, lc, { top: SU.SW, topSh: SU.SS, belt: SU.SD, pelvis: SU.SS, armN: [SU.SW, SU.SW, SU.SD], armF: [SU.SS, SU.SS, SU.SD],
        legN: [SU.SW, SU.SW, SU.BT, SU.SD], legF: [SU.SS, SU.SS, SU.BT, SU.SD] }) }) });
    suitCache.set(spec, r); return r;
  }
  function drawHelmet(g, x0, y0, rows) {
    const w = rows[0].length;
    rows.forEach((row, r) => { for (let c = 0; c < w; c++) {
      if (row[c] !== 'X') continue;
      let col = r <= 1 ? SU.SW : r >= 5 ? SU.SS : (c === 0 ? SU.SS : SU.SW);
      if (r === 7) col = SU.AC; if (c === w - 1 && r >= 2 && r <= 5) col = SU.GL;
      put(g, x0 + c, y0 + r, col);
    } });
    put(g, x0 + 4, y0 + 1, SU.HL); put(g, x0 + w - 1, y0 + 2, SU.HL);
  }
  function drawFlame(g, cols, hy, flame, L) {
    const len = Math.round(2 + 4 * flame), fc = ['#fff2b8', '#ffc24d', '#ff8a33', '#d4502a', '#8a3322'];
    for (let r = 0; r < len; r++) {
      const dx = L > 0 && r >= 3 ? -1 : 0;
      for (const x of cols) {
        if (r >= 3 && x === cols[0] && len >= 5) continue;
        put(g, x + dx, hy - 1 + r, fc[Math.min(4, Math.floor(r * 5 / len))]);
      }
    }
  }
  function drawPack(g, hy, ub, L, flame) {             // 侧面背包：躯干后面两列
    const sh = y => Math.round(L * (hy - 3 - y) / 4);
    if (flame > 0) drawFlame(g, [13, 14], hy, flame, L);
    for (let y = hy - 6 + ub; y <= hy - 3; y++) { const s = sh(y); put(g, 13 + s, y, SU.PK); put(g, 14 + s, y, SU.SS); }
    put(g, 13 + sh(hy - 5 + ub), hy - 5 + ub, SU.AC); put(g, 13, hy - 2, SU.NZ); put(g, 14, hy - 2, SU.NZ);
  }

  /* 画一个完整人物到网格 g（hy 为髋所在行，已含 GOFF）。opts: {suit, flame, noArms} */
  function drawCharacter(g, spec, po, hy, opts) {
    const suit = !!(opts && opts.suit), noArms = !!(opts && opts.noArms); if (suit) spec = suitSpec(spec);
    const b = spec.build, look = spec.look, c = look.cols, o = look.outfit;
    if (po.v34) return drawChar34(g, spec, po, hy, suit, opts);
    const L = po.lean || 0, ub = po.bob || 0, hd = po.head || [0, 0], hx = 15, sy = hy - 6 + ub;
    const LN = legPts(b, po.nl[0], po.nl[1]), LF = legPts(b, po.fl[0], po.fl[1]);
    const shf = y => Math.round(L * (hy - 3 - y) / 4);
    const ox = 13 + L + hd[0], oy = hy - 12 + ub + hd[1];
    if (!noArms) drawArm2(g, armPts(b, po.fa[0], po.fa[1]), 15 + L, sy, c.armF, o === 'labcoat' ? -1 : 0);
    drawLeg2(g, LF, hx, hy, c.legF);
    if (suit) drawPack(g, hy, ub, L, opts.flame || 0);
    if (o === 'labcoat') {                           // 白大褂敞开：只有身后的下摆随风飘，前面露出里面的深色衣服
      const fly = Math.round(clamp(((po.tail ? po.tail[0] : 30) - 10) / 25, 0, 2));
      for (let y = hy - 2; y <= hy + 4; y++) {
        const back = y >= hy + 1 ? fly : 0;
        for (let x = 13 - back + L; x <= 14 + L; x++) put(g, x, y, y === hy + 4 || x < 14 + L ? c.coatSh : c.coat);
      }
    }
    if (look.hair === 'long') {
      const t0 = po.tail ? po.tail[0] : 30;
      for (let r = 0; r < 8; r++) {
        const dx = Math.round(-Math.sin(rad(clamp(t0, -20, 70))) * r * 0.45), x0 = ox - 1 + dx;
        put(g, x0, oy + 2 + r, c.hair); put(g, x0 + 1, oy + 2 + r, r % 3 === 1 ? c.hairHi : c.hair);
      }
    }
    for (let y = hy - 6 + ub; y <= hy - 3; y++) {
      const s = shf(y);
      let bk = c.topSh || c.top, fr = c.top;
      if (o === 'labcoat') { bk = c.coat; fr = c.top; }
      else if (o === 'overalls') { bk = c.top; fr = c.bib; }
      if (y === hy - 6 + ub) {
        if (o === 'labcoat') { bk = c.coat; fr = c.coat; } else if (o === 'vest') fr = c.collar; else if (o === 'hoodie') { fr = c.hood; bk = c.hood; } else if (o === 'overalls') bk = c.bib;
      }
      if (y === hy - 3 && c.belt) { bk = c.belt; fr = c.belt; }
      put(g, 15 + s, y, bk); put(g, 16 + s, y, fr);
    }
    for (let y = hy - 2; y <= hy - 1; y++) { put(g, 15, y, c.pelvis); put(g, 16, y, c.pelvis); }
    if (hd[1] <= 0) put(g, 16 + L, hy - 7 + ub, c.skinSh || c.skin);
    if (o === 'hoodie') { put(g, ox, oy + 5, c.hood); put(g, ox + 1, oy + 5, c.hood); put(g, ox, oy + 6, c.hood); }
    if (suit) put(g, 16 + shf(hy - 5 + ub), hy - 5 + ub, SU.AC);
    if (look.hair === 'ponytail' && !suit) {
      const a1 = rad(po.tail[0]), a2 = rad(po.tail[1]);
      const p0 = [ox + 1, oy], p1 = [p0[0] - 2 * Math.cos(a1), p0[1] + 2 * Math.sin(a1)], p2 = [p1[0] - 2 * Math.cos(a2), p1[1] + 2 * Math.sin(a2)];
      line(g, p0[0], p0[1], p1[0], p1[1], c.hair, 1); line(g, p1[0], p1[1], p2[0], p2[1], c.hair, 1); put(g, p2[0], p2[1], c.hairEnd || c.hair);
    }
    drawHead(g, look, po, ox, oy);
    if (suit) drawHelmet(g, ox - 1, oy - 2, HELM7);
    drawLeg2(g, LN, hx, hy, c.legN);
    if (!noArms) {
      const AN = armPts(b, po.na[0], po.na[1]);
      if (look.prop === 'flask') {
        const hxp = 16 + L + AN.wx, hyp = sy + AN.wy, f = rad(po.na[1]);
        drawFlask(g, hxp, hyp, Math.sin(f), Math.cos(f), c);
      }
      drawArm2(g, AN, 16 + L, sy, c.armN, o === 'labcoat' ? 1 : 0);
    }
  }

  /* ---------- 45° 视角（待机用）----------
   * 身体微转向观众：肩 4 宽、躯干 2 宽、双臂分在两侧、两条腿并排；头 6 列，脸 2 列宽、露出一侧耳朵。
   * 姿势字段：na/fa = 画面左/右臂 [上臂角,前臂角]；nl/fl = 画面左/右腿；角度在画面平面内，向下为0，向画面右为正。 */
  function drawLeg34(g, L, hx, hy, cols, side) {
    line(g, hx, hy, hx + L.kx, hy + L.ky, cols[0], 2);
    line(g, hx + L.kx, hy + L.ky, hx + L.ax, hy + L.ay, cols[1], 2);
    const ax = Math.round(hx + L.ax), ay = Math.round(hy + L.ay);
    if (cols[3]) { put(g, ax, ay - 1, cols[3]); put(g, ax + 1, ay - 1, cols[3]); }
    for (let i = 0; i < 3; i++) put(g, (side < 0 ? ax - 1 : ax) + i, ay, cols[2]);
  }
  function drawChar34(g, spec, po, hy, suit, opts) {
    const b = spec.build, look = spec.look, c = look.cols, o = look.outfit, noArms = !!(opts && opts.noArms);
    const ub = po.bob || 0, hd = po.head || [0, 0], ox = 12 + hd[0], oy = hy - 12 + ub + hd[1], sy = hy - 6 + ub;
    const LA = armPts(b, po.na[0], po.na[1]), RA = armPts(b, po.fa[0], po.fa[1]);
    const LL = legPts(b, po.nl[0], po.nl[1]), RL = legPts(b, po.fl[0], po.fl[1]);
    const t0 = po.tail ? po.tail[0] : 30;
    // 后层：右臂(远)、实验服下摆、长发
    const sl = o === 'labcoat';
    if (!noArms) drawArm2(g, RA, 17, sy, c.armF, sl ? 1 : 0);
    if (look.hair === 'long') {
      for (let r = 0; r < 8; r++) {
        const dx = Math.round(-Math.sin(rad(clamp(t0 - 20, -10, 40))) * r * 0.35), x0 = ox + dx;
        put(g, x0, oy + 2 + r, c.hair); put(g, x0 + 1, oy + 2 + r, r % 3 === 1 ? c.hairHi : c.hair);
      }
    }
    if (suit) {                                     // 背包在躯干后面，喷口在腰后
      if (opts.flame > 0) drawFlame(g, [12, 13], hy, opts.flame);
      for (let y = hy - 6 + ub; y <= hy - 3; y++) { put(g, 12, y, SU.PK); put(g, 13, y, SU.SS); put(g, 14, y, SU.SS); }
      put(g, 12, hy - 5 + ub, SU.AC); put(g, 13, hy - 2, SU.NZ); put(g, 14, hy - 2, SU.NZ);
    }
    drawLeg34(g, RL, 16, hy, c.legF, 1);
    drawLeg34(g, LL, 14, hy, c.legN, -1);
    // 躯干
    for (let y = hy - 6 + ub; y <= hy - 3; y++) {
      let bk = c.topSh || c.top, fr = c.top;
      if (o === 'overalls') { bk = c.top; fr = c.bib; }
      const top = y === hy - 6 + ub;
      if (o === 'labcoat') {
        bk = c.top; fr = c.top; if (y === hy - 3 && c.belt) { bk = c.belt; fr = c.belt; }
        put(g, 14, y, top ? c.coat : c.coatSh); put(g, 17, y, c.coat); put(g, 15, y, top ? c.coat : bk); put(g, 16, y, top ? c.top : fr);   // 翻领：领口一侧是白的
        continue;
      }
      if (top) { if (o === 'vest') fr = c.collar; else if (o === 'hoodie') { fr = c.hood; bk = c.hood; } else if (o === 'overalls') bk = c.bib; }
      if (y === hy - 3 && c.belt) { bk = c.belt; fr = c.belt; }
      if (top) { put(g, 14, y, bk); put(g, 15, y, fr); put(g, 16, y, fr); put(g, 17, y, bk); }
      else { put(g, 15, y, bk); put(g, 16, y, fr); }
    }
    if (o === 'labcoat') {                           // 白大褂半穿、没扣扣子：中间露出里面的深色衣服和裤子，白色只在两侧垂下
      const sway = Math.round(clamp((t0 - 20) / 30, 0, 1));
      for (let y = hy - 2; y <= hy - 1; y++) { put(g, 15, y, c.pelvis); put(g, 16, y, c.pelvis); }
      for (let y = hy - 2; y <= hy + 5; y++) {
        const k = y - (hy - 2), wl = k >= 4 ? 2 : 1;                  // 越往下越外翻
        put(g, 14, y, c.coatSh); if (wl > 1) put(g, 13, y, c.coatSh);
        put(g, 17, y, c.coat); if (wl > 1) put(g, 18, y, c.coat);
        if (y === hy + 5) { put(g, 12 - sway, y, c.coatSh); put(g, 19 + sway, y, c.coat); }
      }
    } else for (let y = hy - 2; y <= hy - 1; y++) { put(g, 15, y, c.pelvis); put(g, 16, y, c.pelvis); }
    if (hd[1] <= 0) { put(g, 15, hy - 7 + ub, c.skinSh || c.skin); if (o === 'hoodie') { put(g, 14, hy - 7 + ub, c.hood); put(g, 16, hy - 7 + ub, c.hood); } }
    if (suit) put(g, 16, hy - 4 + ub, SU.AC);
    if (look.hair === 'ponytail' && !suit) {      // 发尾挂在脑后左侧，几乎垂直下落
      const a1 = rad(po.tail[0]), a2 = rad(po.tail[1]);
      const p0 = [ox, oy + 1], p1 = [p0[0] - 2 * Math.cos(a1), p0[1] + 2 * Math.sin(a1)], p2 = [p1[0] - 2 * Math.cos(a2), p1[1] + 2 * Math.sin(a2)];
      line(g, p0[0], p0[1], p1[0], p1[1], c.hair, 1); line(g, p1[0], p1[1], p2[0], p2[1], c.hair, 1); put(g, p2[0], p2[1], c.hairEnd || c.hair);
    }
    drawHead34(g, look, po, ox, oy);
    if (suit) drawHelmet(g, ox - 1, oy - 2, HELM8);
    if (o === 'hoodie') { put(g, ox + 1, oy + 5, c.hood); put(g, ox + 4, oy + 5, c.hood); }
    // 前层：左臂(近)，可能拿烧瓶
    if (!noArms) {
      if (look.prop === 'flask') { const f = rad(po.na[1]); drawFlask(g, 14 + LA.wx, sy + LA.wy, Math.sin(f), Math.cos(f), c); }
      drawArm2(g, LA, 14, sy, c.armN, sl ? -1 : 0);
    }
  }

  /* ---------- 星界边境风格：独立 360° 手臂骨骼、武器攻击模组与全身连招系统 ---------- */
  const WEAPONS = {
    pistol: {
      id: 'pistol',
      name: '脉冲手枪',
      archetype: 'pistol',
      type: 'ranged',
      grip: '2h',
      clip: 6,
      shootDur: 0.18,
      reloadDur: 0.68,
    },
    blade: {
      id: 'blade',
      name: '铁质长剑',
      archetype: 'sword',
      type: 'melee',
      grip: 'hybrid', // 1段单手屈肘横斩，2-3段与剑气技能双手握持发力
      clip: 0,
      comboCount: 3,
      comboDurs: [0.42, 0.44, 0.54],
      skillDur: 0.76,
      comboNames: ['一段·踏步横斩', '二段·斜撩上挑', '三段·举顶下劈'],
      skillName: '秘技·蓄力剑气',
    },
    // 预留武器模组元数据（刀、枪、戟、盾），便于后续扩展不同攻击模组
    MODULES: {
      sword: { id: 'sword', name: '剑模组 (单/双手)', comboCount: 3, lmb: '三连击：踏步横斩 → 斜撩上挑 → 举顶下劈', rmb: '蓄力剑气斩' },
      katana: { id: 'katana', name: '刀模组 (双手居合)', comboCount: 3, lmb: '疾风三连斩', rmb: '居合拔刀斩' },
      spear: { id: 'spear', name: '枪模组 (双手长柄)', comboCount: 3, lmb: '中平连刺 → 挑杀', rmb: '龙牙突进' },
      halberd: { id: 'halberd', name: '戟模组 (双手重武)', comboCount: 3, lmb: '横扫千军 → 裂地劈', rmb: '霸王回旋震' },
      shield: { id: 'shield', name: '盾模组 (单手防反)', comboCount: 3, lmb: '盾击连打', rmb: '举盾格挡反击' },
    }
  };

  /* 统一近战上半身专属 8 帧步进库 (SWORD_ACT_KF)：
   * 1. 仅驱动上半身骨骼（双臂屈肘 na/fa、微幅躯干倾角 lean ∈ [-1,1]、头部与肩部微移），下肢完全交由当前站立/走/跑/跳步态自然驱动，边跑边砍不滑步；
   * 2. 严格采用 8 帧离散步进像素动画，全程保持自然屈肘（|na[1] - na[0]| ∈ 40°~60°）；
   * 3. 每一段挥砍均具备超过 180° 的大开大合强力挥斩幅度：
   *    - 一段横斩：从背后深拉引剑 (-118°) 爆发 208°~212° 大弧向前水平横斩 (90°→94°)，配环腰 C 形接长水平剑芒拖尾；
   *    - 二段上挑：从后下方 (-76°) 爆发 280° 总跨度（单帧拖尾 > 190°）大幅斜撩越过头顶至脑后 (204°)；
   *    - 三段下劈：双手高举过顶并向后仰 36° (216°) 蓄势，随后爆发 198° 满月长弧重劈至地面 (18°)；
   * 4. 所有近战帧的手臂 (na/fa)、对称尖头长剑 (gunAng) 与刀光拖尾均以肩膀 (sxN, sy) 为支点随鼠标瞄准角 (aim - 90°) 整体旋转。 */
  const SWORD_ACT_KF = {
    // 一段·向前横斩 (0.42s · 基础8帧)：屈肘深拉于背后(-118°) → 爆发 >200° 环腰大弧向前水平横斩(88°→94°) → 沉肘归位
    combo1: [
      { p: 0.00, nl: [-8, -20],  fl: [20, -14],  lean: 0,  bob: 0, head: [0, 0],  tail: [32, 58], na: [-52, -100], fa: [24, 70],   gunAng: -110, bladeScale: 1.0, trailFrom: null, shoulderDx: 0, shoulderDy: 0 },
      { p: 0.14, nl: [-14, -24], fl: [24, -16],  lean: -1, bob: 0, head: [-1, 0], tail: [36, 64], na: [-60, -108], fa: [28, 74],   gunAng: -118, bladeScale: 1.0, trailFrom: null, shoulderDx: 0, shoulderDy: 0 },
      { p: 0.28, nl: [20, -20],  fl: [-18, -22], lean: 1,  bob: 0, head: [1, 0],  tail: [24, 46], na: [34, 82],    fa: [-14, 34],  gunAng: 88,   bladeScale: 1.0, trailFrom: -118, shoulderDx: 1, shoulderDy: 0 },
      { p: 0.42, nl: [36, -22],  fl: [-28, -26], lean: 1,  bob: 0, head: [1, 0],  tail: [18, 34], na: [46, 90],    fa: [-22, 26],  gunAng: 90,   bladeScale: 1.0, trailFrom: -110, shoulderDx: 1, shoulderDy: 0 },
      { p: 0.56, nl: [40, -24],  fl: [-32, -28], lean: 1,  bob: 0, head: [1, 0],  tail: [14, 28], na: [50, 94],    fa: [-26, 22],  gunAng: 94,   bladeScale: 1.0, trailFrom: -92,  shoulderDx: 1, shoulderDy: 0 },
      { p: 0.70, nl: [34, -22],  fl: [-26, -26], lean: 1,  bob: 0, head: [1, 0],  tail: [18, 36], na: [38, 84],    fa: [-18, 26],  gunAng: 88,   bladeScale: 1.0, trailFrom: -54,  shoulderDx: 1, shoulderDy: 0 },
      { p: 0.84, nl: [26, -20],  fl: [-20, -22], lean: 0,  bob: 0, head: [0, 0],  tail: [24, 44], na: [24, 70],    fa: [-12, 30],  gunAng: 80,   bladeScale: 1.0, trailFrom: null, shoulderDx: 0, shoulderDy: 0 },
      { p: 1.00, nl: [18, -18],  fl: [-14, -20], lean: 0,  bob: 0, head: [0, 0],  tail: [28, 50], na: [14, 58],    fa: [-6, 34],   gunAng: 72,   bladeScale: 1.0, trailFrom: null, shoulderDx: 0, shoulderDy: 0 },
    ],
    // 二段·斜撩上挑 (0.44s · 基础8帧)：屈肘深压于身后下方(-76°) → 爆发 >200° 大弧斜撩越过头顶至脑后(204°) → 高位长弧收势
    combo2: [
      { p: 0.00, nl: [28, -30],  fl: [-18, -30], lean: 0,  bob: 0, head: [0, 1],  tail: [28, 52], na: [-26, -74],  fa: [-18, -64], gunAng: -68,  bladeScale: 1.0, trailFrom: null, twoHand: true, shoulderDx: 0, shoulderDy: 0 },
      { p: 0.14, nl: [32, -34],  fl: [-22, -34], lean: 1,  bob: 1, head: [1, 1],  tail: [30, 56], na: [-32, -82],  fa: [-24, -72], gunAng: -76,  bladeScale: 1.0, trailFrom: null, twoHand: true, shoulderDx: 0, shoulderDy: 0 },
      { p: 0.28, nl: [30, -24],  fl: [-24, -26], lean: 1,  bob: 0, head: [1, 0],  tail: [34, 60], na: [44, 100],   fa: [32, 86],   gunAng: 108,  bladeScale: 1.0, trailFrom: -76,  twoHand: true, shoulderDx: 1, shoulderDy: 0 },
      { p: 0.42, nl: [24, -14],  fl: [-28, -20], lean: 0,  bob: 0, head: [0, -1], tail: [40, 68], na: [112, 168],  fa: [98, 154],  gunAng: 186,  bladeScale: 1.0, trailFrom: -38,  twoHand: true, shoulderDx: 1, shoulderDy: -1 },
      { p: 0.56, nl: [20, -10],  fl: [-30, -16], lean: -1, bob: 0, head: [0, -1], tail: [44, 74], na: [134, 190],  fa: [120, 176], gunAng: 204,  bladeScale: 1.0, trailFrom: 12,   twoHand: true, shoulderDx: 0, shoulderDy: -1 },
      { p: 0.70, nl: [22, -12],  fl: [-26, -18], lean: -1, bob: 0, head: [0, -1], tail: [42, 70], na: [124, 180],  fa: [110, 166], gunAng: 194,  bladeScale: 1.0, trailFrom: 68,   twoHand: true, shoulderDx: 0, shoulderDy: -1 },
      { p: 0.84, nl: [24, -16],  fl: [-22, -20], lean: 0,  bob: 0, head: [0, 0],  tail: [36, 62], na: [98, 154],   fa: [84, 140],  gunAng: 164,  bladeScale: 1.0, trailFrom: null, twoHand: true, shoulderDx: 0, shoulderDy: 0 },
      { p: 1.00, nl: [26, -20],  fl: [-18, -22], lean: 0,  bob: 0, head: [0, 0],  tail: [32, 58], na: [78, 134],   fa: [64, 120],  gunAng: 144,  bladeScale: 1.0, trailFrom: null, twoHand: true, shoulderDx: 0, shoulderDy: 0 },
    ],
    // 三段·举顶下劈 (0.54s · 基础8帧)：双手举剑过顶并向后仰 36°(gunAng=216°) → 沿头顶至地面拉出 198° 满月长拖尾重劈(18°) → 震地收势
    combo3: [
      { p: 0.00, nl: [28, -22],  fl: [-20, -24], lean: 0,  bob: 0, head: [0, -1], tail: [36, 62], na: [124, 180],  fa: [112, 168], gunAng: 192,  bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 1, shoulderDx: 0, shoulderDy: -1 },
      { p: 0.14, nl: [32, -28],  fl: [-22, -28], lean: -1, bob: 0, head: [-1, -1],tail: [42, 70], na: [136, 192],  fa: [124, 180], gunAng: 210,  bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 1, shoulderDx: 0, shoulderDy: -1 },
      { p: 0.28, nl: [34, -32],  fl: [-24, -30], lean: -1, bob: 0, head: [-1, -1],tail: [46, 76], na: [144, 200],  fa: [132, 188], gunAng: 216,  bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 2, shoulderDx: 0, shoulderDy: -1 },
      { p: 0.42, nl: [36, -26],  fl: [-28, -26], lean: 1,  bob: 0, head: [1, 0],  tail: [26, 48], na: [42, 98],    fa: [28, 84],   gunAng: 86,   bladeScale: 1.0, trailFrom: 216,  twoHand: true, chargeLv: 2, shoulderDx: 1, shoulderDy: 0 },
      { p: 0.56, nl: [42, -30],  fl: [-34, -30], lean: 1,  bob: 1, head: [1, 1],  tail: [16, 30], na: [2, 48],     fa: [-6, 38],   gunAng: 20,   bladeScale: 1.0, trailFrom: 216,  twoHand: true, chargeLv: 2, shoulderDx: 1, shoulderDy: 0, slamBurst: 0.9 },
      { p: 0.70, nl: [44, -32],  fl: [-36, -32], lean: 1,  bob: 1, head: [1, 1],  tail: [14, 26], na: [0, 46],     fa: [-8, 36],   gunAng: 18,   bladeScale: 1.0, trailFrom: 204,  twoHand: true, chargeLv: 2, shoulderDx: 1, shoulderDy: 0, slamBurst: 1.0 },
      { p: 0.84, nl: [38, -28],  fl: [-30, -28], lean: 1,  bob: 0, head: [1, 0],  tail: [18, 34], na: [6, 52],     fa: [-4, 42],   gunAng: 32,   bladeScale: 1.0, trailFrom: 96,   twoHand: true, chargeLv: 1, shoulderDx: 1, shoulderDy: 0, slamBurst: 0.4 },
      { p: 1.00, nl: [28, -22],  fl: [-20, -24], lean: 0,  bob: 0, head: [0, 0],  tail: [24, 46], na: [14, 62],    fa: [4, 50],    gunAng: 62,   bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 0, shoulderDx: 0, shoulderDy: 0 },
    ],
    // 右键秘技·蓄力剑气 (0.76s · 基础8帧)：屈肘深收于腰后蓄力(-76°) → 爆发 >190° 大幅挥斩释放冷铁剑气波(116°→158°) → 稳姿收剑
    skill: [
      { p: 0.00, nl: [24, -24],  fl: [-18, -20], lean: 0,  bob: 0, head: [1, 0],  tail: [34, 60], na: [-18, -62],  fa: [-10, -52], gunAng: -56,  bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 1, shoulderDx: 0, shoulderDy: 0 },
      { p: 0.14, nl: [28, -28],  fl: [-22, -22], lean: -1, bob: 0, head: [1, 0],  tail: [38, 66], na: [-22, -68],  fa: [-14, -58], gunAng: -64,  bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 1, shoulderDx: 0, shoulderDy: 0 },
      { p: 0.28, nl: [30, -30],  fl: [-24, -24], lean: -1, bob: 1, head: [1, 0],  tail: [42, 70], na: [-26, -74],  fa: [-18, -64], gunAng: -72,  bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 2, shoulderDx: 0, shoulderDy: 0 },
      { p: 0.42, nl: [32, -32],  fl: [-26, -26], lean: -1, bob: 1, head: [1, 0],  tail: [44, 74], na: [-28, -76],  fa: [-20, -66], gunAng: -76,  bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 2, shoulderDx: 0, shoulderDy: 0 },
      { p: 0.56, nl: [38, -24],  fl: [-30, -26], lean: 1,  bob: 0, head: [1, 0],  tail: [20, 38], na: [48, 106],   fa: [34, 92],   gunAng: 116,  bladeScale: 1.0, trailFrom: -76,  twoHand: true, chargeLv: 2, shoulderDx: 1, shoulderDy: 0 },
      { p: 0.70, nl: [42, -26],  fl: [-34, -28], lean: 1,  bob: 0, head: [1, 0],  tail: [14, 28], na: [88, 146],   fa: [74, 132],  gunAng: 158,  bladeScale: 1.0, trailFrom: -44,  twoHand: true, chargeLv: 2, shoulderDx: 1, shoulderDy: -1 },
      { p: 0.84, nl: [34, -22],  fl: [-26, -24], lean: 1,  bob: 0, head: [1, 0],  tail: [20, 38], na: [62, 120],   fa: [48, 106],  gunAng: 132,  bladeScale: 1.0, trailFrom: 48,   twoHand: true, chargeLv: 1, shoulderDx: 1, shoulderDy: 0 },
      { p: 1.00, nl: [24, -20],  fl: [-18, -22], lean: 0,  bob: 0, head: [0, 0],  tail: [26, 48], na: [16, 66],    fa: [4, 52],    gunAng: 72,   bladeScale: 1.0, trailFrom: null, twoHand: true, chargeLv: 0, shoulderDx: 0, shoulderDy: 0 },
    ],
  };
  SWORD_ACT_KF.combo4 = SWORD_ACT_KF.combo3;
  SWORD_ACT_KF.swing = SWORD_ACT_KF.combo1;

  /* 严格按 8 帧离散步进采样（不插值过渡），保证近战挥砍与全身像素步态帧率风格完全统一 */
  function sampleSwordKF(act, p) {
    const list = SWORD_ACT_KF[act];
    if (!list) return null;
    const u = clamp(p || 0, 0, 0.9999);
    const idx = clamp(Math.floor(u * list.length), 0, list.length - 1);
    const k = list[idx];
    return {
      frameIdx: idx,
      nl: [k.nl[0], k.nl[1]],
      fl: [k.fl[0], k.fl[1]],
      lean: k.lean || 0,
      bob: k.bob || 0,
      head: k.head ? [k.head[0], k.head[1]] : [0, 0],
      tail: [k.tail[0], k.tail[1]],
      na: [k.na[0], k.na[1]],
      fa: [k.fa[0], k.fa[1]],
      gunAng: k.gunAng,
      bladeScale: 1.0,
      trailFrom: k.trailFrom != null ? k.trailFrom : null,
      twoHand: !!k.twoHand,
      chargeLv: k.chargeLv || 0,
      hopY: 0,
      shoulderDx: k.shoulderDx || 0,
      shoulderDy: k.shoulderDy || 0,
      slamBurst: k.slamBurst || 0,
      spinFlip: false,
      spinRing: 0,
    };
  }

  /* 近战连招与技能仅驱动上半身专属骨骼（双臂屈肘、微幅上身倾角、头部、发尾、肩部偏移），
   * 下肢 (nl, fl) 与离地高度完全保留底层走/跑/跳/站立姿态，彻底消除边跑边打时的滑步平移感；
   * 同时将双臂与武器单独剥离，以肩膀为支点按鼠标瞄准角 (aimRot = aim - 90°) 整体旋转 */
  function computeMeleeBodyPose(basePo, w) {
    if (!w || (w.id !== 'blade' && w.id !== 'sword')) return { po: basePo, spinFlip: false, hopY: 0 };
    const act = w.action || 'aim', p = clamp(w.p || 0, 0, 1);
    const kf = sampleSwordKF(act, p);
    if (!kf) return { po: basePo, spinFlip: false, hopY: 0 };
    const aim = (w && w.aim != null) ? w.aim : 90;
    const aimRot = basePo && basePo.v34 ? 0 : (aim - 90);
    const out = Object.assign({}, basePo, {
      lean: clamp(kf.lean || 0, -1, 1),
      bob: kf.bob || 0,
      head: kf.head,
      na: [kf.na[0] + aimRot, kf.na[1] + aimRot],
      fa: [kf.fa[0] + aimRot, kf.fa[1] + aimRot],
      tail: kf.tail,
      shoulderDx: kf.shoulderDx,
      shoulderDy: kf.shoulderDy,
    });
    return { po: out, spinFlip: false, hopY: 0 };
  }

  function computeWeaponPose(w) {
    const id = (w && w.id) || 'pistol', aim = (w && w.aim != null) ? w.aim : 90, act = (w && w.action) || 'aim', p = clamp((w && w.p) || 0, 0, 1);
    const v34 = !!(w && w.v34);
    const aimRot = v34 ? 0 : (aim - 90);
    let na = [aim - 6, aim], fa = [aim - 14, aim + 8], gunAng = aim;
    let slideBack = 0, flash = 0, casing = -1, magDrop = 0, handMag = false, magLockGlow = false, rackGlint = false;
    let slashArc = -1, slashType = null, bladeScale = 1, twoHand = false, chargeLv = 0, spinPhase = 0, idleGlint = -1, trailFrom = null, spinRing = 0, slamBurst = 0, shoulderDx = 0, shoulderDy = 0;

    if (id === 'blade' || id === 'sword' || act === 'swing' || act.startsWith('combo') || act === 'skill') {
      if (act === 'idle' || (v34 && act === 'aim')) {
        // 铁质长剑 · 45° 刚体待机姿态：角度与手腕关节完全锁定（不发生逐帧角度形变），整把剑随上身呼吸(po.bob)做整像素刚体平移
        na = [-10, 46];
        fa = [18, 10];
        gunAng = 124;
        idleGlint = p;
      } else if (SWORD_ACT_KF[act]) {
        const kf = sampleSwordKF(act, p);
        // 剥离后的双臂与长剑在肩膀支点处随鼠标瞄准方向 (aimRot = aim - 90°) 整体旋转
        na = [kf.na[0] + aimRot, kf.na[1] + aimRot];
        fa = [kf.fa[0] + aimRot, kf.fa[1] + aimRot];
        gunAng = kf.gunAng + aimRot;
        bladeScale = 1.0;
        twoHand = kf.twoHand;
        chargeLv = kf.chargeLv;
        slamBurst = kf.slamBurst || 0;
        shoulderDx = kf.shoulderDx || 0;
        shoulderDy = kf.shoulderDy || 0;
        if (kf.trailFrom != null) {
          trailFrom = kf.trailFrom + aimRot;
          slashArc = p;
          slashType =
            act === 'combo1' || act === 'swing'
              ? 'horiz'
              : act === 'combo2'
              ? 'diagUp'
              : act === 'combo3' || act === 'combo4'
              ? 'heavySlam'
              : 'skillWave';
        }
      } else {
        // 侧面持剑瞄准/移动姿态：手臂与铁剑同样以肩膀为支点随鼠标 360° 旋转，手肘保持自然弯曲
        na = [-12 + aimRot, 48 + aimRot];
        fa = [18 + aimRot, 68 + aimRot];
        gunAng = 114 + aimRot;
      }
      return { id: 'blade', aim, aimRot, act, p, na, fa, gunAng, slideBack, flash, casing, magDrop, handMag, magLockGlow, rackGlint, slashArc, slashType, bladeScale, twoHand, chargeLv, spinPhase, idleGlint, trailFrom, spinRing, slamBurst, shoulderDx, shoulderDy };
    }

    if (act === 'idle' || (v34 && act === 'aim')) {
      // 脉冲手枪 · 45° 刚体待机姿态：枪身角度与双臂关节固定，整把枪随人物上身呼吸(po.bob)做整像素刚体上下平移
      na = [-4, 68];
      fa = [20, -6];
      gunAng = 90;
      idleGlint = p;
    } else if (act === 'shoot') {
      const recoil = p < 0.28 ? (p / 0.28) * 26 : 26 * Math.max(0, 1 - (p - 0.28) / 0.72);
      gunAng = aim + recoil;
      na = [aim - 10 - recoil * 0.35, gunAng];
      fa = [aim - 18 - recoil * 0.2, aim + 6 + recoil * 0.5];
      slideBack = p < 0.45 ? 1 : 0;
      flash = p < 0.22 ? 2 : p < 0.44 ? 1 : 0;
      if (p >= 0.12 && p <= 0.82) casing = (p - 0.12) / 0.7;
    } else if (act === 'reload') {
      if (p < 0.25) {
        const u = p / 0.25;
        gunAng = aim + 30 * u;
        na = [aim - 16 * u, gunAng];
        fa = [aim - 14 - 20 * u, aim + 8 - 24 * u];
        magDrop = 1 + Math.round(u * 4.5);
      } else if (p < 0.52) {
        const u = (p - 0.25) / 0.27;
        gunAng = aim + 30 + 4 * Math.sin(u * Math.PI);
        na = [aim - 18, gunAng];
        fa = u < 0.5 ? [-18, 18] : [-18 + (aim - 2) * ((u - 0.5) * 2), 18 + (aim + 8) * ((u - 0.5) * 2)];
        handMag = true;
      } else if (p < 0.76) {
        const u = (p - 0.52) / 0.24, tap = Math.sin(u * Math.PI) * 8;
        gunAng = aim + 30 + tap;
        na = [aim - 16 + tap * 0.4, gunAng];
        fa = [aim - 12, gunAng - 4];
        magLockGlow = u >= 0.35 && u <= 0.88;
      } else {
        const u = (p - 0.76) / 0.24;
        if (u < 0.55) {
          gunAng = aim + 18;
          na = [aim - 14, gunAng];
          fa = [aim + 6, gunAng + 18];
          slideBack = 1;
          rackGlint = true;
        } else {
          const k = (u - 0.55) / 0.45;
          gunAng = aim + 18 * (1 - k);
          na = [aim - 14 + 8 * k, gunAng];
          fa = [aim - 14, aim + 8];
          slideBack = 0;
        }
      }
    }
    return { id, aim, aimRot, act, p, na, fa, gunAng, slideBack, flash, casing, magDrop, handMag, magLockGlow, rackGlint, slashArc, slashType, bladeScale, twoHand, chargeLv, spinPhase, idleGlint, trailFrom, spinRing, slamBurst, shoulderDx, shoulderDy };
  }

  /* 严格绑定在对称尖头长剑几何上的冷白/暗铁长弧刀光残影 (drawSlashTrail)：
   * - 向前横斩 (horiz)：参考用户提供的透视横斩拖尾图，从人物后背/后腰处拉出环腰 C 形厚新月弧（左下带三齿残影流苏），
   *   向前汇入包裹整把长剑的宽幅水平横斩光带，并在剑尖前方拉出修长锐利的水平突刺剑芒；
   * - 斜撩上挑 / 举顶下劈 / 剑气斩 (diagUp / heavySlam / skillWave)：以握剑手腕 (hx, hyW) 为圆心、剑尖 (13.0) 为外径，
   *   从前一帧轨迹角 wp.trailFrom 连续扫掠超过 180° 至当前剑身角 wp.gunAng。 */
  function drawSlashTrail(gWep, hx, hyW, wp) {
    if (wp.trailFrom == null || !wp.slashType) return;
    const edgeWhite = '#eef1f6', steelLight = '#9aa1b0', steelMid = '#646a78', steelDark = '#3d414b';
    const rMax = 13.0;
    const a0 = wp.trailFrom, a1 = wp.gunAng;
    const diff = a1 - a0;
    if (Math.abs(diff) < 3) return;

    if (wp.slashType === 'horiz') {
      const ang = rad(wp.gunAng);
      const ux = Math.sin(ang), uy = Math.cos(ang);
      // 垂直于挥砍前向的画面下方法向 (dnX, dnY)：当水平朝右 (gunAng=90°) 时，(ux,uy)=(1,0)，(dnX,dnY)=(0,1)
      const dnX = -uy, dnY = ux;
      const putH = (u, d, col) => {
        const px = hx + u * ux + d * dnX;
        const py = clamp(hyW + u * uy + d * dnY, 34, 75.5);
        put(gWep, px, py, col);
      };
      const isPeak = Math.abs(diff) >= 175;

      // 1) 后背环腰 C 形厚新月弧（参考图左侧：从肩背处 u=-9..-5, d=-2 起手，向后背左外侧 u=-14..-6, d=-1..+2 弯出饱满 C 弧，左下带三根垂直残影齿）
      if (isPeak) {
        // C 弧上沿起手弯钩（紧贴肩背下方，不遮挡头部）
        for (let u = -10; u <= -5; u++) {
          putH(u, -2, u <= -7 ? edgeWhite : steelLight);
        }
        // C 弧后背左外缘厚月牙主体 (u = -14 .. -5, d = -1 .. +2)
        for (let d = -1; d <= 2; d++) {
          const uLeft = d === 0 || d === 1 ? -14 : d === -1 ? -12 : -13;
          const uRight = d === -1 ? -6 : -4;
          for (let u = uLeft; u <= uRight; u++) {
            const isInnerRim = d <= 0 && u >= uRight - 1;
            putH(u, d, isInnerRim ? steelLight : edgeWhite);
          }
        }
        // 参考图标志性细节：C 弧左下方三根垂直向下的残影齿 (u = -12, -10, -8)
        for (const uTooth of [-12, -10, -8]) {
          putH(uTooth, 3, edgeWhite);
          putH(uTooth, 4, steelLight);
        }
      } else {
        // 收势帧：保留后腰半弧残影
        for (let u = -10; u <= -3; u++) {
          putH(u, 0, steelMid);
          putH(u, 1, steelLight);
          putH(u, 2, edgeWhite);
        }
      }

      // 2) 前方一体式纯白水平横斩宽刃带（参考图中部至右侧：从腰后 u=-6 连续拉出 3~4px 宽的高对比纯白横斩光带至 u=+14）
      const uStart = isPeak ? -6 : -2;
      const uBandEnd = isPeak ? 14 : 13;
      for (let u = uStart; u <= uBandEnd; u++) {
        if (u >= 0 && u <= 11) {
          putH(u, -1, steelLight);
        }
        putH(u, 0, edgeWhite);
        putH(u, 1, edgeWhite);
        putH(u, 2, edgeWhite);
        if (isPeak && u >= -5 && u <= 12) {
          putH(u, 3, edgeWhite);
        }
      }

      // 3) 远端修长水平尖刺延伸（参考图最右侧：突破剑尖向右前方拉出细长水平剑芒至 u=20，并在最末端带 1px 上挑尖峰）
      const uSpikeMax = isPeak ? 20 : 16;
      for (let u = uBandEnd + 1; u <= uSpikeMax; u++) {
        if (u <= uBandEnd + 2) {
          putH(u, 1, edgeWhite);
          putH(u, 2, edgeWhite);
        } else {
          putH(u, 2, edgeWhite);
        }
      }
      if (isPeak) {
        putH(uSpikeMax, 1, edgeWhite);
      }
      return;
    }

    const steps = Math.max(26, Math.min(64, Math.round(Math.abs(diff) * 0.36)));
    for (let s = 0; s <= steps; s++) {
      const u = s / steps;
      const ang = rad(a0 + diff * u);
      const ux = Math.sin(ang), uy = Math.cos(ang);
      // 挥砍过程中手臂绕肩关节同步大幅摆动，历史轨迹段 (u < 1) 叠加手臂摆幅补偿，使过顶上挑与举顶下劈形成完整包络全身的大满弧
      const armSwingBoost = (1 - u) * 4.6;
      const rOuter = rMax + armSwingBoost;
      const rIn = u > 0.66
        ? 2.4
        : u > 0.28
        ? (3.6 + (0.66 - u) * 8.0)
        : (6.8 + (0.28 - u) * 10.5);

      for (let r = rIn; r <= rOuter; r += 0.8) {
        const px = hx + ux * r, py = clamp(hyW + uy * r, 34, 75.5);
        const isTipRim = r >= rOuter - 1.8;
        let col = steelDark;
        if (u > 0.74) col = isTipRim ? edgeWhite : steelLight;
        else if (u > 0.40) col = isTipRim ? steelLight : steelMid;
        else col = isTipRim ? steelMid : steelDark;
        put(gWep, px, py, col);
      }
    }

    // 三段·举顶下劈落地瞬间：在加长剑尖触地处激发冷铁锋芒与暗灰碎石震地冲击
    if (wp.slamBurst > 0) {
      const ang = rad(wp.gunAng);
      const tipX = hx + Math.sin(ang) * 12.2;
      const tipY = Math.min(75.0, hyW + Math.cos(ang) * 12.2);
      const hBurst = Math.round(5 * wp.slamBurst);
      for (let dx = -2; dx <= 2; dx++) {
        put(gWep, tipX + dx, tipY, Math.abs(dx) <= 1 ? edgeWhite : steelMid);
      }
      for (let dy = 1; dy <= hBurst; dy++) {
        put(gWep, tipX, tipY - dy, dy <= 2 ? edgeWhite : steelLight);
        if (dy <= hBurst - 1) {
          put(gWep, tipX - 2, tipY - dy, steelMid);
          put(gWep, tipX + 2, tipY - dy, steelMid);
        }
      }
    }
  }

  function drawWeaponLayers(gBack, gWep, gFront, spec, po, hy, opts) {
    const suit = !!(opts && opts.suit); if (suit) spec = suitSpec(spec);
    const b = spec.build, look = spec.look, c = look.cols, o = look.outfit;
    const wp = computeWeaponPose(Object.assign({}, opts.weapon, { v34: !!po.v34 }));
    const L = po.v34 ? 0 : (po.lean || 0), ub = po.bob || 0;
    const sdx = po.v34 ? 0 : (po.shoulderDx || wp.shoulderDx || 0);
    const sdy = po.v34 ? 0 : (po.shoulderDy || wp.shoulderDy || 0);
    // 肩膀旋转中心 (sxN, sy)：单独剥离的前臂、后臂与武器均以此肩膀关节为支点随鼠标旋转
    const sy = hy - 6 + ub + sdy;
    const sxN = po.v34 ? 14 : 16 + L + sdx;
    const rotRad = rad(po.v34 ? 0 : (wp.aimRot || 0));
    const sxF = po.v34 ? 17 : (sxN - Math.cos(rotRad));
    const syF = po.v34 ? sy : (sy + Math.sin(rotRad));
    const AF = armPts(b, wp.fa[0], wp.fa[1]), AN = armPts(b, wp.na[0], wp.na[1]);

    // 1. 后臂图层 (backArm)：以肩膀支点旋转后的远端肩位 (sxF, syF) 绘制
    drawArm2(gBack, AF, sxF, syF, c.armF, o === 'labcoat' ? (po.v34 ? 1 : -1) : 0);
    if (wp.handMag) {
      const fx = Math.round(sxF + AF.wx), fy = Math.round(syF + AF.wy);
      put(gBack, fx, fy - 1, '#3e4556'); put(gBack, fx, fy - 2, '#ef7b3a'); put(gBack, fx + 1, fy - 2, '#6be6ff');
    }

    // 2. 武器精灵图层 (weapon) —— 握持原点取整保证剑身上下双刃关于中轴严格像素对称
    const hx = Math.round(sxN + AN.wx);
    const hyW = Math.round(sy + AN.wy);
    const ux = Math.sin(rad(wp.gunAng)), uy = Math.cos(rad(wp.gunAng));
    const isBlade = wp.id === 'blade' || wp.id === 'sword';
    const flipUp = (!isBlade && ux < -0.25) ? -1 : 1;
    const nx = uy * flipUp, ny = -ux * flipUp;
    const pt = (u, v) => [hx + u * ux + v * nx, hyW + u * uy + v * ny];

    let muzzle = { x: Math.round(hx + 5.5 * ux + 1.2 * nx), y: Math.round(hyW + 5.5 * uy + 1.2 * ny), ux, uy };

    if (isBlade) {
      // 先画紧贴剑身后方的冷白/暗铁刀光残影扇面，再画对称双刃尖头长剑在最前缘
      drawSlashTrail(gWep, hx, hyW, wp);

      // 对称双刃尖头铁质长剑（全长至菱形尖头 13.0px）：
      // 1) 对称剑首配重球 (Pommel #686e7c) + 深炭剑柄 (Grip #2b2e36) + 上下严格对称的十字宽护手 (Crossguard v=±2.0 #4a4f5c)
      const isHorizFlash = wp.slashType === 'horiz' && wp.trailFrom != null && Math.abs(wp.gunAng - wp.trailFrom) >= 175;
      const pPom = pt(-2.0, 0), pHilt = pt(1.0, 0), pTip = pt(13.0, 0);
      const pG1 = pt(1.5, 2.0), pG2 = pt(1.5, -2.0);
      line(gWep, pPom[0], pPom[1], pHilt[0], pHilt[1], '#2b2e36', 1);
      put(gWep, pPom[0], pPom[1], '#686e7c');
      line(gWep, pG1[0], pG1[1], pG2[0], pG2[1], '#4a4f5c', 1);
      put(gWep, pt(1.5, 0)[0], pt(1.5, 0)[1], '#7d8494');

      // 2) 上下完全对称开刃的直剑剑身 (v = ±1.0 同色冷白铁刃 #dce1eb) + 中轴暗铁血槽剑脊 (v = 0 #4e5463 / #8a91a1) + 对称收尖剑头 (u=12..13, v=0)
      const colCore = isHorizFlash ? '#dce1eb' : (wp.chargeLv >= 2 ? '#7d8494' : '#4e5463');
      const colBody = isHorizFlash ? '#dce1eb' : (wp.chargeLv >= 1 ? '#b8bfd0' : '#8a91a1');
      const colEdge = '#dce1eb';
      const colTip = '#f2f4f8';
      // 上下对称双刃 (u = 2.0 .. 11.0, v = ±1.0)
      line(gWep, pt(2.0, -1.0)[0], pt(2.0, -1.0)[1], pt(11.0, -1.0)[0], pt(11.0, -1.0)[1], colEdge, 1);
      line(gWep, pt(2.0,  1.0)[0], pt(2.0,  1.0)[1], pt(11.0,  1.0)[0], pt(11.0,  1.0)[1], colEdge, 1);
      // 中轴血槽与剑脊 (u = 2.0 .. 11.0, v = 0)
      line(gWep, pt(2.0, 0)[0], pt(2.0, 0)[1], pt(8.0, 0)[0], pt(8.0, 0)[1], colCore, 1);
      line(gWep, pt(8.0, 0)[0], pt(8.0, 0)[1], pt(11.0, 0)[0], pt(11.0, 0)[1], colBody, 1);
      // 对称收拢尖头部：从 3px 宽双刃对称收束至中轴 u=12.0 (#dce1eb) 与 u=13.0 (#f2f4f8) 锐利剑尖
      put(gWep, pt(12.0, 0)[0], pt(12.0, 0)[1], colEdge);
      put(gWep, pTip[0], pTip[1], colTip);

      // 45° 持剑待机专属剑脊冷光：剑身像素完全刚体锁定，仅在已有剑身像素上改变一粒冷白高光颜色
      if (wp.idleGlint >= 0) {
        const gu = 2.6 + wp.idleGlint * 9.0;
        const gp = pt(gu, 0);
        recolor(gWep, gp[0], gp[1], '#f2f4f8');
      }

      // 蓄力剑气聚能寒芒：紧贴对称铁剑两侧流动的冷白/铁灰剑芒
      if (wp.chargeLv > 0 && wp.slashArc < 0) {
        const stride = wp.chargeLv >= 2 ? 1.8 : 2.8;
        const phase = Math.round(wp.p * 8) % 2;
        for (let u = 2.6; u <= 12.0; u += stride) {
          const side = ((Math.round(u) + phase) % 2 === 0 ? 1 : -1) * 1.25;
          const gp = pt(u, side);
          put(gWep, gp[0], gp[1], wp.chargeLv >= 2 ? '#eef1f6' : '#9aa1b0');
        }
      }

      muzzle = { x: Math.round(pTip[0]), y: Math.round(pTip[1]), ux, uy };
    } else {
      // 脉冲手枪：握把、枪身下机匣、可动滑套、能量准星、掉落/锁定弹匣、枪口火焰与抛壳
      const g0 = pt(0, 0), g1 = pt(-0.6, -1.3);
      line(gWep, g0[0], g0[1], g1[0], g1[1], '#2b303c', 1);
      const r0 = pt(-0.5, 0.6), r1 = pt(3.8, 0.6);
      line(gWep, r0[0], r0[1], r1[0], r1[1], '#495264', 1);
      const sb = wp.slideBack * 1.1;
      const s0 = pt(-0.8 - sb, 1.3), s1 = pt(4.6 - sb * 0.3, 1.3);
      line(gWep, s0[0], s0[1], s1[0], s1[1], '#9ba8bc', 1);
      const h0 = pt(0 - sb, 1.8), h1 = pt(3.6 - sb * 0.3, 1.8);
      line(gWep, h0[0], h0[1], h1[0], h1[1], '#d5e0ee', 1);
      const core = pt(1.6 - sb * 0.5, 1.3);
      const coreCol = wp.slideBack
        ? '#ff9e44'
        : (wp.idleGlint >= 0.45 && wp.idleGlint <= 0.75)
        ? '#ffffff'
        : '#6be6ff';
      put(gWep, core[0], core[1], coreCol);
      const mz = pt(4.9, 1.2);
      put(gWep, mz[0], mz[1], '#2b303c');
      muzzle = { x: Math.round(mz[0] + ux), y: Math.round(mz[1] + uy), ux, uy };

      if (wp.magDrop > 0) {
        const md = pt(-0.4, -1.2);
        put(gWep, md[0], md[1] + wp.magDrop, '#3a4150');
        put(gWep, md[0], md[1] + wp.magDrop - 1, '#ef7b3a');
      }
      if (wp.magLockGlow) {
        const mg = pt(0, -0.5);
        put(gWep, mg[0], mg[1], '#96ebff');
      }
      if (wp.rackGlint) {
        const rg = pt(0.5, 2.2);
        put(gWep, rg[0], rg[1], '#ffd257');
      }
      if (wp.flash > 0) {
        const f1 = pt(5.8, 1.2), f2 = pt(7.2, 1.2), f3 = pt(8.4, 1.2);
        const fU = pt(6.4, 2.3), fD = pt(6.4, 0.1);
        put(gWep, f1[0], f1[1], '#ffffff');
        put(gWep, f2[0], f2[1], '#fff19e');
        if (wp.flash > 1) {
          put(gWep, f3[0], f3[1], '#ff8e36');
          put(gWep, fU[0], fU[1], '#ffc44d');
          put(gWep, fD[0], fD[1], '#ffc44d');
        }
      }
      if (wp.casing >= 0) {
        const ej = pt(1.0, 2.2);
        const cx = ej[0] - ux * (1 + wp.casing * 4.5), cy = ej[1] - 2.2 * Math.sin(wp.casing * Math.PI) + wp.casing * 2.5;
        put(gWep, cx, cy, '#f2c654');
      }
    }

    // 3. 前臂图层 (frontArm)：画在武器握把外侧，呈现手掌握枪/握剑与袖口包裹感
    drawArm2(gFront, AN, sxN, sy, c.armN, o === 'labcoat' ? (po.v34 ? -1 : 1) : 0);
    return { muzzle, shoulder: { x: sxN, y: sy }, wp };
  }

  function charLayers(spec, po, hy, phi, opts) {
    const backArm = mkG(), body = mkG(), weapon = mkG(), frontArm = mkG(), composite = mkG();
    const hasWep = !!(opts && opts.weapon && opts.weapon.id && opts.weapon.id !== 'none' && !phi && !(po && po.inFlip));
    if (!hasWep) {
      drawCharacter(body, spec, po, hy + GOFF, opts);
      let out = body;
      if (phi) {
        const o = mkG(), cc = Math.cos(rad(phi)), ss = Math.sin(rad(phi)), cx = 17.5 + GX, cy = hy + GOFF - 4;
        for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
          const dx = x + 0.5 - cx, dy = y + 0.5 - cy, sx = Math.floor(cx + dx * cc + dy * ss), sy = Math.floor(cy - dx * ss + dy * cc);
          if (sx >= 0 && sy >= 0 && sx < GW && sy < GH && body[sy][sx]) o[y][x] = body[sy][sx];
        }
        for (let y = 1; y < GH - 1; y++) for (let x = 1; x < GW - 1; x++) {
          if (!o[y][x] && ((o[y][x - 1] && o[y][x + 1] && (o[y - 1][x] || o[y + 1][x])) || (o[y - 1][x] && o[y + 1][x] && (o[y][x - 1] || o[y][x + 1])))) {
            o[y][x] = o[y][x - 1] || o[y - 1][x];
          }
        }
        out = o;
      }
      for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) composite[y][x] = out[y][x];
      return { backArm, body: out, weapon, frontArm, composite, muzzle: null, shoulder: { x: 16, y: hy + GOFF - 6 }, decoupled: false };
    }

    const meleeBody = computeMeleeBodyPose(po, opts.weapon);
    const activePo = meleeBody.po;
    const activeHy = gHy(spec.build, norm(activePo)) - meleeBody.hopY;
    drawCharacter(body, spec, activePo, activeHy + GOFF, Object.assign({}, opts, { noArms: true }));

    const meta = drawWeaponLayers(backArm, weapon, frontArm, spec, activePo, activeHy + GOFF, opts);
    for (const layer of [backArm, body, weapon, frontArm]) {
      for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) if (layer[y][x]) composite[y][x] = layer[y][x];
    }
    return { backArm, body, weapon, frontArm, composite, muzzle: meta.muzzle, shoulder: meta.shoulder, wp: meta.wp, decoupled: true };
  }

  function charGrid(spec, po, hy, phi, opts) {
    return charLayers(spec, po, hy, phi, opts).composite;
  }

  /* ---------- 姿势库 ---------- */
  const norm = po => Object.assign({ head: [0, 0], lean: 0, bob: 0, tail: [28, 58] }, po);
  const mixArr = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
  function blend(a, b, t) {
    a = norm(a); b = norm(b);
    const o = {};
    for (const k of ['nl', 'fl', 'na', 'fa', 'tail', 'head']) o[k] = mixArr(a[k], b[k], t);
    o.lean = Math.round(a.lean + (b.lean - a.lean) * t); o.bob = Math.round(a.bob + (b.bob - a.bob) * t);
    if (a.hy != null && b.hy != null) o.hy = Math.round(a.hy + (b.hy - a.hy) * t);
    if (a.inFlip || b.inFlip) o.inFlip = true;
    o.blink = b.blink; return o;
  }
  function walkBase(i, sw) {
    const p = i / 8 * Math.PI * 2, q = p + Math.PI, nth = 30 * Math.sin(p), fth = 30 * Math.sin(q);
    const nb = 8 + 50 * Math.max(0, Math.cos(p)), fb = 8 + 50 * Math.max(0, Math.cos(q));
    const nu = -30 * Math.sin(p) * sw, fu = -30 * Math.sin(q) * sw;
    return norm({ nl: [nth, nth - nb], fl: [fth, fth - fb], na: [nu, nu + (22 + 14 * Math.max(0, -Math.sin(p))) * sw], fa: [fu, fu + (22 + 14 * Math.max(0, -Math.sin(q))) * sw],
      tail: [28 + 14 * Math.sin(p - 0.5), 58 + 14 * Math.sin(p - 0.5) + 14 * Math.sin(p - 1.5)] });
  }
  /* 持武瞄准前方、人物向后倒退时的专属「后退走 (walkBack)」与「后退跑 (runBack)」8 帧动画：
   * 区别于向前走/跑（前倾 + 后踢小腿 + 从后往前迈步），后退动作保持上身直立或微后仰稳住重心、目光锁定前方，
   * 前脚撑地向后推身体，随后前膝微提将腿向身后撤收，脚尖向臀后探出触地承重，支撑腿随身体后移从后侧滑向前侧。 */
  const WBLEG = [
    [26, -10],   // 0: 前脚撑地向后蹬推身体
    [20, -40],   // 1: 前脚离地、屈膝向后收腿
    [2,  -44],   // 2: 摆动腿掠过髋部下方向身后撤
    [-18, -28],  // 3: 脚尖向身后探出准备触地
    [-24, -18],  // 4: 后脚在臀后稳稳落步承重
    [-10, -14],  // 5: 身体后移越过支撑腿
    [8,  -12],   // 6: 支撑腿相对髋部移至前下方
    [20, -10],   // 7: 准备下一轮前脚向后蹬推
  ];
  function walkBackBase(i, sw) {
    const p = i / 8 * Math.PI * 2, q = p + Math.PI;
    const nu = 22 * Math.sin(p) * sw, fu = 22 * Math.sin(q) * sw;
    return norm({
      nl: WBLEG[i],
      fl: WBLEG[(i + 4) % 8],
      na: [nu, nu + 20 * sw],
      fa: [fu, fu + 20 * sw],
      lean: 0,
      bob: (i === 1 || i === 5) ? 1 : 0,
      head: [1, 0],
      tail: [38 + 8 * Math.sin(p), 66 + 10 * Math.sin(p - 0.6)],
    });
  }
  const RL = [[30, 22], [32, -55], [-5, -12], [-30, -40], [-25, -95], [5, -100], [40, -60], [55, 10]];
  function runBase(i) {
    const sn = Math.sin(2 * Math.PI * (i - 1.5) / 8), sf = Math.sin(2 * Math.PI * (i + 4 - 1.5 - 0.4) / 8);
    const un = 5 + 50 * sn, uf = 5 + 46 * sf, p = i / 8 * Math.PI * 2, fl = (i === 3 || i === 7) ? 6 : 0, a1 = 8 + 10 * Math.sin(p - 0.5) - fl;
    return norm({ nl: RL[i], fl: RL[(i + 4) % 8], na: [un, un + 70 + 25 * sn], fa: [uf, uf + 68 + 22 * sf], tail: [a1, a1 + 14 + 10 * Math.sin(p - 1.5)], lean: 1 });
  }
  const RBLEG = [
    [34, -14],   // 0: 前脚全力向后蹬地推离
    [24, -52],   // 1: 前腿折叠屈膝快速向后抽回
    [-4, -50],   // 2: 悬空腿高速向身后摆动
    [-28, -32],  // 3: 脚掌大幅向身后远端探出
    [-26, -24],  // 4: 后脚在身后触地缓冲
    [-10, -22],  // 5: 重心急退越过支撑腿
    [12, -18],   // 6: 支撑腿转入前侧持续后推
    [26, -14],   // 7: 前脚蓄势准备再次向后蹬离
  ];
  function runBackBase(i) {
    const p = i / 8 * Math.PI * 2, sn_ = Math.sin(p), sf_ = Math.sin(p + Math.PI);
    const un = -10 + 36 * sn_, uf = -10 + 34 * sf_;
    return norm({
      nl: RBLEG[i],
      fl: RBLEG[(i + 4) % 8],
      na: [un, un + 55],
      fa: [uf, uf + 52],
      lean: -1,
      bob: (i === 0 || i === 4) ? 1 : 0,
      head: [1, 0],
      tail: [46 + 10 * Math.sin(p), 74 + 12 * Math.sin(p - 0.5)],
    });
  }
  const ARM = { cross: [[30, -85], [30, -85]], chin: [[58, 172], [25, -80]], hips: [[30, -70], [30, -70]], hug: [[10, -100], [10, -100]], flask: [[82, 128], null] };
  const P = {
    skid: { nl: [38, 28], fl: [-18, -40], na: [70, 110], fa: [-60, -100], tail: [50, 75], lean: -1 },
    crouch: { nl: [34, -38], fl: [24, -44], na: [-35, -12], fa: [-18, -4], tail: [35, 62], lean: 1, bob: 1 },
    spring: { nl: [16, -22], fl: [10, -24], na: [12, 24], fa: [-12, -4], tail: [40, 65] },
    land: { nl: [38, -42], fl: [28, -46], na: [36, 62], fa: [-24, -8], tail: [50, 75], lean: 1, bob: 1 },
    tuck: { nl: [125, -50], fl: [120, -55], na: [65, 15], fa: [55, 10], tail: [70, 88], lean: 2, bob: 2, head: [1, 2], hy: 35, inFlip: true },
    uncurl: { nl: [28, -34], fl: [6, -24], na: [82, 98], fa: [-80, -94], tail: [22, 44], lean: 1, bob: 1, head: [0, 1], hy: 35, inFlip: true }
  };
  const FLIP_STEPS = [30, 80, 130, 180, 230, 280, 325, 0];
  const SLEG = [[36, 26], [30, -62], [-28, -22], [-45, -80], [-20, -110], [30, -75], [70, -20], [62, 15]];
  function sprintBase(i) {                         // 冲刺：身体更前倾，摆臂和步幅更大
    const sn_ = Math.sin(2 * Math.PI * (i - 1.5) / 8), sf = Math.sin(2 * Math.PI * (i + 4 - 1.5 - 0.4) / 8);
    const un = 65 * sn_, uf = 60 * sf, p = i / 8 * Math.PI * 2, fl = (i === 3 || i === 7) ? 5 : 0, a1 = 3 + 6 * Math.sin(p - 0.5) - fl;
    return norm({ nl: SLEG[i], fl: SLEG[(i + 4) % 8], na: [un, un + 80 + 20 * sn_], fa: [uf, uf + 78 + 18 * sf], tail: [a1, a1 + 8 + 8 * Math.sin(p - 1.5)], lean: 2 });
  }
  const CWLEG = [[30, -50], [36, -34], [38, -26], [34, -34], [26, -38], [16, -46], [8, -50], [18, -56]];
  function crouchWalkBase(i) {                     // 蹲行：压低重心、膝盖收在胸前下方、小腿向后自然折叠交替猫步
    const p = i / 8 * Math.PI * 2, s_ = Math.sin(p);
    return norm({ nl: CWLEG[i], fl: CWLEG[(i + 4) % 8], na: [16 - 12 * s_, 46 - 12 * s_], fa: [12 + 12 * s_, 40 + 10 * s_], tail: [38 + 5 * Math.sin(p - 0.5), 64 + 6 * Math.sin(p - 1)], lean: 1, bob: 1, head: [0, 1] });
  }
  function crouchWalkBackBase(i) {                 // 蹲姿后退：猫步逆序向后撤步，上身稳住目光朝前
    const ri = (8 - (i % 8)) % 8, p = i / 8 * Math.PI * 2, s_ = Math.sin(p);
    return norm({ nl: CWLEG[ri], fl: CWLEG[(ri + 4) % 8], na: [14 + 10 * s_, 44 + 10 * s_], fa: [10 - 10 * s_, 38 - 10 * s_], tail: [44 + 5 * Math.sin(p), 70 + 6 * Math.sin(p - 0.8)], lean: 0, bob: 1, head: [1, 1] });
  }
  const PX = {
    crouchIdle: { nl: [34, -38], fl: [24, -44], na: [18, 48], fa: [12, 40], tail: [38, 64], lean: 1, bob: 1, head: [0, 1] },
    blinkWind: { nl: [42, -52], fl: [28, -58], na: [-75, -35], fa: [-55, -10], tail: [10, 25], lean: 2, bob: 1 },
    blinkLand: { nl: [38, -28], fl: [-36, -48], na: [-62, -20], fa: [52, 95], tail: [5, 15], lean: 2, bob: 1 }
  };
  const KICK = [   // 太空服二段跳：上升段手臂向下，接近顶点时平滑抬起衔接空中下落
    [0,    { nl: [20, -42], fl: [4, -36],   na: [20, 36],  fa: [-18, -8],   tail: [32, 56], lean: 1, bob: 1, head: [0, 1] }],
    [0.09, { nl: [22, -52], fl: [-14, -28], na: [12, 24],  fa: [-22, -12],  tail: [10, 24], lean: 1, bob: 0, head: [0, 0] }],
    [0.2,  { nl: [18, -34], fl: [-10, -22], na: [34, 48],  fa: [-32, -22],  tail: [6, 18],  lean: 1, bob: 0, head: [0, 0] }],
    [0.3,  { nl: [16, -22], fl: [-6, -18],  na: [94, 108], fa: [-94, -106], tail: [14, 32], lean: 0, bob: 0, head: [0, 0] }]];
  function kickPose(t) {
    for (let i = 0; i < KICK.length - 1; i++) if (t <= KICK[i + 1][0]) return blend(KICK[i][1], KICK[i + 1][1], (t - KICK[i][0]) / (KICK[i + 1][0] - KICK[i][0]));
    return norm(KICK[KICK.length - 1][1]);
  }
  const AK = [     // 跳跃空中：上升时(v>0)双臂向下；下落时(v<=0)双臂偏上，且随下落时间与水平夹角单调增大
    [2.5,  { nl: [-6, -14], fl: [-12, -20], na: [12, 24],   fa: [-12, -4],    tail: [55, 80] }],
    [1.6,  { nl: [8, -20],  fl: [-14, -24], na: [16, 30],   fa: [-16, -8],    tail: [45, 70] }],
    [0.8,  { nl: [14, -22], fl: [-10, -20], na: [24, 40],   fa: [-22, -12],   tail: [30, 55] }],
    [0.4,  { nl: [15, -22], fl: [-8, -19],  na: [34, 48],   fa: [-32, -22],   tail: [22, 44] }],
    [0.0,  { nl: [16, -22], fl: [-6, -18],  na: [94, 108],  fa: [-94, -106],  tail: [14, 32] }],
    [-0.8, { nl: [14, -18], fl: [-6, -16],  na: [106, 122], fa: [-104, -118], tail: [-10, 10] }],
    [-1.6, { nl: [10, -10], fl: [-6, -12],  na: [118, 136], fa: [-116, -132], tail: [-28, -8] }],
    [-2.6, { nl: [8, -4],   fl: [-8, -10],  na: [130, 150], fa: [-128, -146], tail: [-42, -20] }]
  ];
  function airPose(v) {
    let po;
    if (v >= AK[0][0]) po = norm(AK[0][1]);
    else {
      for (let i = 0; i < AK.length - 1; i++) if (v <= AK[i][0] && v > AK[i + 1][0]) { po = blend(AK[i][1], AK[i + 1][1], (AK[i][0] - v) / (AK[i][0] - AK[i + 1][0])); break; }
      if (!po) po = norm(AK[AK.length - 1][1]);
    }
    po.isAir = true;
    return po;
  }

  /* ---------- 性格专属待机骨架动作 ---------- */
  const ph = (t, c) => ((t % c) + c) % c;
  const IDLES = {
    // 冷静：抱臂，慢呼吸，偶尔换重心
    cross(t, talk) {
      const u = ph(t, 3.2) / 3.2, bob = u < 0.38 ? 0 : u < 0.72 ? -1 : 0, sh = ph(t, 7.5);
      const shift = sh > 5.8 && sh < 6.7;
      return norm({ nl: shift ? [10, 5] : [3, 0], fl: shift ? [-8, -7] : [-3, -2], na: ARM.cross[0], fa: ARM.cross[1], tail: [26 + 3 * Math.sin(t * 1.6), 52 + 4 * Math.sin(t * 1.9)], bob, head: [0, talk && Math.sin(t * 7) > 0.6 ? 1 : 0] });
    },
    // 沉思：手托下巴，低头，指尖轻敲
    think(t, talk) {
      const u = ph(t, 3.8) / 3.8, bob = u < 0.4 ? 0 : u < 0.75 ? -1 : 0, look = ph(t, 9) < 4 ? 1 : 0, tap = ph(t, 2.6) > 2.25 ? 1 : 0;
      return norm({ nl: [6, 0], fl: [-5, -4], na: [58 + (tap ? 8 : 0), 172 - (tap ? 10 : 0)], fa: ARM.chin[1], tail: [30, 55], lean: look, bob, head: [0, talk ? (Math.sin(t * 5) > 0 ? 1 : 0) : look] });
    },
    // 健谈：举着瓶子比划，脚尖弹跳，点头
    talk(t) {
      const s = Math.sin(t * 3.2), bob = Math.sin(t * 6.5) > 0.4 ? -1 : 0;
      return norm({ nl: [3 + (bob ? 0 : 6), bob ? 0 : -8], fl: [-3, -2 - (bob ? 0 : 6)], na: [98 + 18 * s, 142 + 22 * Math.sin(t * 3.2 + 0.8)],
        fa: [45 + 30 * Math.sin(t * 2.4 + 1), 85 + 25 * Math.sin(t * 2.4 + 1.6)], tail: [20 + 10 * Math.sin(t * 3), 45 + 12 * Math.sin(t * 3 + 1)], bob, head: [0, Math.sin(t * 3.2) > 0.7 ? 1 : 0] });
    },
    // 暴躁：叉腰，分腿站，跺脚，叹气
    hips(t, talk) {
      const st = ph(t, 3.4), stomp = st > 2.9 && st < 3.15, sg = ph(t, 6.5), sigh = sg > 5.2 && sg < 6.0;
      const na = talk ? [85 + 15 * Math.sin(t * 4), 120] : ARM.hips[0];
      return norm({ nl: stomp ? [34, -34] : [12, 6], fl: [-12, -10], na, fa: ARM.hips[1], tail: [25, 50], bob: sigh ? 1 : 0, head: [0, sigh ? 1 : 0] });
    },
    // 胆小：抱住自己，缩肩，脚尖点地，偶尔偷看
    hug(t, talk) {
      const gl = ph(t, 8), glance = gl > 6.6 && gl < 7.3, tp = Math.sin(t * 5) > 0.6 && ph(t, 6) < 2;
      return norm({ nl: [2, 0], fl: tp ? [8, -2] : [0, 0], na: ARM.hug[0], fa: ARM.hug[1], tail: [32, 60], lean: glance ? 0 : 1, bob: glance ? 0 : (talk && Math.sin(t * 9) > 0 ? 0 : 1), head: [0, glance ? 0 : 1] });
    },
    // 自在（侧面）：供持枪瞄准站立时保持身体呼吸与换重心
    free(t, talk) {
      const u = ph(t, 3.4) / 3.4, bob = u < 0.35 ? 0 : u < 0.7 ? -1 : 0, sh = ph(t, 8.5), shift = sh > 6.4 && sh < 7.4;
      return norm({ nl: shift ? [8, 2] : [3, 0], fl: shift ? [-6, -4] : [-3, -2], na: [6, 14], fa: [-6, -4], tail: [26 + 3 * Math.sin(t * 1.5), 52 + 4 * Math.sin(t * 1.8)], bob, head: [0, talk && Math.sin(t * 7) > 0.6 ? 1 : 0] });
    }
  };

  /* ---------- 45° 待机（性格专属骨架动作，主用）---------- */
  const n34 = o => Object.assign({ v34: true, head: [0, 0], bob: 0, lean: 0, tail: [72, 86] }, o);
  const sn = Math.sin;
  const IDLES34 = {
    // 冷静：双臂在胸前交叉，慢呼吸，偶尔换重心
    cross(t, talk) {
      const u = ph(t, 3.2) / 3.2, bob = u < 0.38 ? 0 : u < 0.72 ? -1 : 0, sh = ph(t, 7.5), shift = sh > 5.8 && sh < 6.7;
      return n34({ nl: shift ? [-12, -9] : [-4, -2], fl: shift ? [4, 2] : [3, 2], na: [-6, 98], fa: [6, -98],
        tail: [72 + 4 * sn(t * 1.6), 86 + 5 * sn(t * 1.9)], bob, head: [0, talk && sn(t * 7) > 0.6 ? 1 : 0] });
    },
    // 沉思：一只手托下巴、另一只手托住手肘，低头，指尖轻敲
    think(t, talk) {
      const u = ph(t, 3.8) / 3.8, bob = u < 0.4 ? 0 : u < 0.75 ? -1 : 0, look = ph(t, 9) < 4 ? 1 : 0, tap = ph(t, 2.6) > 2.25 ? 1 : 0;
      return n34({ nl: [-3, -2], fl: [4, 3], na: [-5, 92], fa: [50, tap ? 222 : 230], tail: [72, 86], bob, head: [0, talk ? (sn(t * 5) > 0 ? 1 : 0) : look] });
    },
    // 健谈：举着烧瓶比划，另一只手跟着摆，脚尖弹跳，点头
    talk(t) {
      const s = sn(t * 3.2), up = sn(t * 6.5) > 0.4;                    // 脚尖弹跳只动腿，不抬躯干，避免身体变长、腿显短
      return n34({ nl: [-4 + (up ? 0 : -6), -2 + (up ? 0 : 6)], fl: [4, 3 - (up ? 0 : 4)], na: [-70 + 15 * s, -165 + 20 * sn(t * 3.2 + 0.8)],
        fa: [55 + 22 * sn(t * 2.4 + 1), 100 + 25 * sn(t * 2.4 + 1.6)], tail: [20 + 8 * sn(t * 3), 40 + 10 * sn(t * 3 + 1)], bob: 0, head: [0, sn(t * 3.2) > 0.7 ? 1 : 0] });
    },
    // 暴躁：双手叉腰，分腿站，跺脚，叹气
    hips(t, talk) {
      const st = ph(t, 3.4), stomp = st > 2.9 && st < 3.15, sg = ph(t, 6.5), sigh = sg > 5.2 && sg < 6.0;
      const na = talk ? [-78 + 12 * sn(t * 4), -105] : [-48, 52];
      return n34({ nl: [-14, -10], fl: stomp ? [26, -26] : [14, 10], na, fa: [48, -52], tail: [30, 50], bob: sigh ? 1 : 0, head: [0, sigh ? 1 : 0] });
    },
    // 自在：双臂自然下垂，上身慢呼吸，偶尔换脚、偶尔环顾（没有性格倾向的基础待机）
    free(t, talk) {
      const u = ph(t, 3.4) / 3.4, bob = u < 0.35 ? 0 : u < 0.7 ? -1 : 0, sh = ph(t, 8.5), shift = sh > 6.4 && sh < 7.4, gl = ph(t, 11), look = gl > 8.6 && gl < 9.8;
      const sw = sn(t * 1.3), ba = ph(t - 0.25, 3.4) / 3.4 > 0.35 && ph(t - 0.25, 3.4) / 3.4 < 0.7 ? 1 : 0;
      return n34({ nl: shift ? [-9, -5] : [-4, -2], fl: shift ? [2, 1] : [3, 2], na: [-9 - 2 * ba + sw, -4 - 3 * ba], fa: [9 + 2 * ba - sw, 4 + 3 * ba],
        tail: [72 + 4 * sn(t * 1.5), 86 + 5 * sn(t * 1.8)], bob, head: [look ? 1 : 0, talk && sn(t * 7) > 0.6 ? 1 : 0] });
    },
    // 胆小：双臂抱住自己，缩肩，膝盖内扣，脚尖点地，偶尔偷看
    hug(t, talk) {
      const gl = ph(t, 8), glance = gl > 6.6 && gl < 7.3, tp = sn(t * 5) > 0.6 && ph(t, 6) < 2;
      return n34({ nl: [5, -2], fl: tp ? [-8, 2] : [-3, 3], na: [-14, 112], fa: [14, -112], tail: [72, 86], bob: glance ? 0 : (talk && sn(t * 9) > 0 ? 0 : 1), head: [glance ? 1 : 0, glance ? 0 : 1] });
    }
  };

  /* ---------- 每把武器专属的 45° 侧身待机动作（应用到所有角色，武器与持武手臂角度完全锁定、随呼吸整像素刚体平移）---------- */
  const WEAPON_IDLES34 = {
    // 星界长剑（剑模组）45° 待机：沉稳剑士 45° 侧身站姿，双臂角度固定，随上身呼吸(bob)整把剑刚体上下平移
    blade(t, talk) {
      const u = ph(t, 2.4) / 2.4, s = sn(u * Math.PI * 2), c = Math.cos(u * Math.PI * 2);
      const bob = (u >= 0.30 && u < 0.72) ? -1 : 0;
      const shift = u >= 0.55 && u < 0.88;
      const look = u >= 0.68 && u < 0.92;
      return n34({
        nl: shift ? [-9, -5] : [-5, -2],
        fl: shift ? [10, 5] : [7, 4],
        na: [-10, 46],
        fa: [18, 10],
        tail: [70 + 5 * s, 84 + 6 * c],
        bob,
        head: [look ? 1 : 0, talk && sn(t * 7) > 0.5 ? 1 : 0],
      });
    },
    // 脉冲手枪（手枪模组）45° 待机：神枪手 45° 战术戒备站姿，双臂与枪身角度固定，随上身呼吸(bob)整把枪刚体上下平移
    pistol(t, talk) {
      const u = ph(t, 2.2) / 2.2, s = sn(u * Math.PI * 2), c = Math.cos(u * Math.PI * 2);
      const bob = (u >= 0.34 && u < 0.74) ? -1 : 0;
      const tap = u >= 0.48 && u < 0.76;
      const scan = u >= 0.64 && u < 0.90;
      return n34({
        nl: tap ? [-8, -2] : [-4, -2],
        fl: tap ? [10, 5] : [6, 3],
        na: [-4, 68],
        fa: [20, -6],
        tail: [72 + 4 * s, 86 + 5 * c],
        bob,
        head: [scan ? 1 : 0, talk && sn(t * 7) > 0.5 ? 1 : 0],
      });
    },
  };
  WEAPON_IDLES34.sword = WEAPON_IDLES34.blade;
  WEAPONS.IDLES34 = WEAPON_IDLES34;

  function poser(spec) {
    const b = spec.build, g = spec.gait || {};
    const sw = g.swing == null ? 1 : g.swing;
    return {
      hyGround: po => gHy(b, norm(po)),
      idle: (t, talk) => (spec.idleView === 'side' ? IDLES : IDLES34)[spec.idle](t, talk),
      idleSide: (t, talk) => (IDLES[spec.idle] || IDLES.free)(t, talk),
      weaponIdle: (wId, t, talk) => (WEAPON_IDLES34[wId] || WEAPON_IDLES34.blade)(t, talk),
      stand: () => norm({ nl: [3, 0], fl: [-3, -2], na: [6, 14], fa: [-6, -4], tail: [26, 52] }),
      loco(mode, i) {
        if (mode === 'sprint') return sprintBase(i);
        if (mode === 'cwalk') return crouchWalkBase(i);
        if (mode === 'cwalkBack') return crouchWalkBackBase(i);
        if (mode === 'run') { const po = runBase(i); po.lean += g.lean ? 1 : 0; return po; }
        if (mode === 'runBack') return runBackBase(i);
        if (mode === 'walkBack') return walkBackBase(i, sw);
        const po = walkBase(i, sw), m = g.walkArms;
        if (m === 'pocket') { po.na = [po.na[0] * 0.5, po.na[0] * 0.5 + 10]; po.fa = [po.fa[0] * 0.5, po.fa[0] * 0.5 + 10]; }
        else if (ARM[m]) { po.na = ARM[m][0]; if (ARM[m][1]) po.fa = ARM[m][1]; }
        po.lean += g.lean || 0;
        if (g.stomp && (i === 0 || i === 4)) po.bob = 1;
        return po;
      },
      runBob: i => i === 3 || i === 7,
      runBackBob: i => i === 2 || i === 6,
      crouchIdle: () => norm(PX.crouchIdle), blinkWind: () => norm(PX.blinkWind), blinkLand: () => norm(PX.blinkLand), kick: t => kickPose(t),
      skid: () => norm(P.skid),
      pre: t => norm(t < 0.07 ? P.crouch : P.spring),
      land: t => norm(t < 0.07 ? P.land : P.crouch),
      air: v => airPose(v),
      flip(ft) {
        const idx = clamp(Math.floor((ft / 0.24) * 8), 0, 7);
        return idx === 7 ? { po: norm(P.uncurl), phi: 0 } : { po: norm(P.tuck), phi: FLIP_STEPS[idx] };
      }
    };
  }

  return { GW, GH, GX, GOFF, FOOT, SHY, SKELETON, WEAPONS, HEADS, IDLES, IDLES34, WEAPON_IDLES34, SWORD_ACT_KF, sampleSwordKF, SUIT: SU, drawCharacter, charLayers, charGrid, computeWeaponPose, computeMeleeBodyPose, poser, blend, norm, gHy, rad, clamp };
});
